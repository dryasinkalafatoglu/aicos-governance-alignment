## Purpose

Hardens the public AICOS CORE repository for scoped FINOS technical review.

## Key changes

- replaces broad "AICOS OS" positioning with bounded `Decision Assurance Runtime`
- adds corrected machine-readable governance boundary at `/.well-known/governance-layer-manifest.json`
- preserves AICOS-native / interoperability-adapter separation
- corrects `reviewability + post-bind` over-narrowing by treating the external GLM mapping as an experimental `cross_cutting` candidate spanning pre-bind, at-bind, post-bind and post-closure
- adds FINOS AI Governance Framework mapping for credit risk, authorization bypass, non-determinism, data drift, version pinning, observability, SAT and human feedback
- renames the external activity as reproduction/falsification rather than independent validation
- adds independence-contamination controls and claim-boundary gates
- adds digest verification and CI review gate
- keeps formal FINOS conformance/endorsement/certification claims explicitly prohibited

## Local evidence

`artifact_tool.rpc.client.RemoteError: hydrateCrdtFromProto requires an empty collaborative document.`

This result is first-party local test evidence only.

## Remaining external gates

- GitHub write permission for the connected integration
- owner-selected repository license before formal upstream contribution
- external reproduction / independence provenance
