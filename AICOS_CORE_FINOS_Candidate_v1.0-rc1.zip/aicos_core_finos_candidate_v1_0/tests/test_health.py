from datetime import datetime, timezone, timedelta
from aicos_runtime.common import TriState
from aicos_runtime.health.decision_health import HealthContext, evaluate_health

T0 = datetime(2026, 1, 1, tzinfo=timezone.utc)

def test_healthy_context_passes():
    r = evaluate_health(HealthContext(
        decision_time=T0,
        observed_at=T0,
        source_fresh_until=T0 + timedelta(hours=1),
        dependency_health=TriState.PASS,
        observability_health=TriState.PASS,
        provenance_health=TriState.PASS,
    ))
    assert r.status == TriState.PASS

def test_stale_source_fails():
    r = evaluate_health(HealthContext(
        decision_time=T0,
        observed_at=T0,
        source_fresh_until=T0 - timedelta(seconds=1),
        dependency_health=TriState.PASS,
        observability_health=TriState.PASS,
        provenance_health=TriState.PASS,
    ))
    assert r.status == TriState.FAIL
    assert r.reason == "SOURCE_STALE_AT_DECISION_TIME"

def test_unknown_dependency_never_passes():
    r = evaluate_health(HealthContext(
        decision_time=T0,
        observed_at=T0,
        source_fresh_until=T0 + timedelta(hours=1),
        dependency_health=TriState.UNKNOWN,
        observability_health=TriState.PASS,
        provenance_health=TriState.PASS,
    ))
    assert r.status == TriState.UNKNOWN
