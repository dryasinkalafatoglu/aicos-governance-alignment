from aicos_runtime.common import TriState
from aicos_runtime.environment.runtime_integrity import evaluate_runtime_integrity

def test_clean_runtime_passes():
    r = evaluate_runtime_integrity(
        ["/opt/aicos/lib", "/opt/aicos/site-packages"],
        ["/opt/aicos"],
        None,
        "/home/aicos",
        "/home/aicos",
    )
    assert r.status == TriState.PASS

def test_untrusted_sys_path_blocks():
    r = evaluate_runtime_integrity(
        ["/opt/aicos/lib", "/tmp/injected"],
        ["/opt/aicos"],
        None,
        "/home/aicos",
        "/home/aicos",
    )
    assert r.status == TriState.FAIL
    assert r.reason == "UNTRUSTED_SYS_PATH_ENTRY"

def test_pythonpath_override_blocks():
    r = evaluate_runtime_integrity(
        ["/opt/aicos/lib"],
        ["/opt/aicos"],
        "/tmp/evil",
        "/home/aicos",
        "/home/aicos",
    )
    assert r.status == TriState.FAIL
    assert r.reason == "PYTHONPATH_OVERRIDE_PRESENT"

def test_unknown_home_never_passes_when_expected():
    r = evaluate_runtime_integrity(
        ["/opt/aicos/lib"],
        ["/opt/aicos"],
        None,
        None,
        "/home/aicos",
    )
    assert r.status == TriState.UNKNOWN
