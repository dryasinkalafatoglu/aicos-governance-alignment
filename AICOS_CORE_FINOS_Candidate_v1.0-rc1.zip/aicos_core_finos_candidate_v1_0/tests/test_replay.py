from aicos_runtime.replay.deterministic_replay import ReplayEnvelope, verify_replay

def env():
    return ReplayEnvelope(
        decision_id="D-1",
        decision_time="2026-09-24T12:00:00Z",
        policy_hash="p1",
        trust_root_hash="t1",
        evidence_graph_hash="e1",
        input_hash="i1",
        expected_result="PASS",
    )

def test_replay_exact_snapshot_passes():
    e = env()
    assert verify_replay(e, {
        "policy_hash":"p1",
        "trust_root_hash":"t1",
        "evidence_graph_hash":"e1",
        "input_hash":"i1",
        "result":"PASS",
    })

def test_replay_with_changed_policy_fails():
    e = env()
    assert not verify_replay(e, {
        "policy_hash":"p2",
        "trust_root_hash":"t1",
        "evidence_graph_hash":"e1",
        "input_hash":"i1",
        "result":"PASS",
    })

def test_replay_with_changed_trust_root_fails():
    e = env()
    assert not verify_replay(e, {
        "policy_hash":"p1",
        "trust_root_hash":"t2",
        "evidence_graph_hash":"e1",
        "input_hash":"i1",
        "result":"PASS",
    })

def test_replay_with_changed_result_fails():
    e = env()
    assert not verify_replay(e, {
        "policy_hash":"p1",
        "trust_root_hash":"t1",
        "evidence_graph_hash":"e1",
        "input_hash":"i1",
        "result":"BLOCK",
    })
