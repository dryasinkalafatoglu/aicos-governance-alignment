from datetime import datetime, timezone, timedelta
from aicos_runtime.common import TriState
from aicos_runtime.temporal_policy.policy_binding import PolicyBinding, evaluate_policy_at_decision_time

T0 = datetime(2026, 1, 1, tzinfo=timezone.utc)

def test_policy_valid_at_decision_time():
    p = PolicyBinding("P1", "1.0", T0 - timedelta(days=1), T0 + timedelta(days=1), "h1")
    assert evaluate_policy_at_decision_time(p, T0).status == TriState.PASS

def test_future_policy_blocks():
    p = PolicyBinding("P1", "1.0", T0 + timedelta(seconds=1), None, "h1")
    assert evaluate_policy_at_decision_time(p, T0).reason == "POLICY_NOT_YET_EFFECTIVE"

def test_expired_policy_blocks():
    p = PolicyBinding("P1", "1.0", T0 - timedelta(days=2), T0, "h1")
    assert evaluate_policy_at_decision_time(p, T0).reason == "POLICY_EXPIRED_AT_DECISION_TIME"

def test_missing_policy_hash_unknown():
    p = PolicyBinding("P1", "1.0", T0 - timedelta(days=1), None, "")
    assert evaluate_policy_at_decision_time(p, T0).status == TriState.UNKNOWN
