from aicos_runtime.common import TriState, Permission
from aicos_runtime.release.release_gate import evaluate_release_gate

def test_release_allowed_only_when_all_pass():
    r = evaluate_release_gate(
        TriState.PASS, TriState.PASS, TriState.PASS, TriState.PASS, Permission.ALLOW
    )
    assert r.status == Permission.ALLOW

def test_unknown_manifest_holds_release():
    r = evaluate_release_gate(
        TriState.PASS, TriState.UNKNOWN, TriState.PASS, TriState.PASS, Permission.ALLOW
    )
    assert r.status == Permission.HOLD

def test_failed_replay_blocks_release():
    r = evaluate_release_gate(
        TriState.PASS, TriState.PASS, TriState.PASS, TriState.FAIL, Permission.ALLOW
    )
    assert r.status == Permission.BLOCK

def test_blocked_claim_blocks_release():
    r = evaluate_release_gate(
        TriState.PASS, TriState.PASS, TriState.PASS, TriState.PASS, Permission.BLOCK
    )
    assert r.status == Permission.BLOCK

def test_downgraded_claim_holds_release():
    r = evaluate_release_gate(
        TriState.PASS, TriState.PASS, TriState.PASS, TriState.PASS, Permission.DOWNGRADE
    )
    assert r.status == Permission.HOLD
