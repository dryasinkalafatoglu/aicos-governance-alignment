from datetime import datetime, timezone, timedelta
from aicos_runtime.common import TriState
from aicos_runtime.claims.claim_validity import ClaimValidityWindow, evaluate_claim_validity

T0 = datetime(2026, 1, 1, tzinfo=timezone.utc)

def test_claim_valid_with_matching_snapshot():
    w = ClaimValidityWindow(T0 - timedelta(days=1), T0 + timedelta(days=1), "e1")
    assert evaluate_claim_validity(w, T0, "e1").status == TriState.PASS

def test_claim_expires():
    w = ClaimValidityWindow(T0 - timedelta(days=2), T0, "e1")
    r = evaluate_claim_validity(w, T0, "e1")
    assert r.status == TriState.FAIL
    assert r.reason == "CLAIM_EXPIRED"

def test_snapshot_mismatch_blocks():
    w = ClaimValidityWindow(T0 - timedelta(days=1), None, "e1")
    r = evaluate_claim_validity(w, T0, "e2")
    assert r.status == TriState.FAIL
    assert r.reason == "CLAIM_EVIDENCE_SNAPSHOT_MISMATCH"

def test_unknown_snapshot_never_passes():
    w = ClaimValidityWindow(T0 - timedelta(days=1), None, None)
    assert evaluate_claim_validity(w, T0, None).status == TriState.UNKNOWN
