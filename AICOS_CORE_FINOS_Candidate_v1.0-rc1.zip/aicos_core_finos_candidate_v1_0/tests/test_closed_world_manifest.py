from aicos_runtime.common import TriState
from aicos_runtime.manifest.closed_world import evaluate_closed_world_manifest

def test_exact_manifest_passes():
    r = evaluate_closed_world_manifest(
        ["aicos_runtime/a.py", "policies/p.json", "trust/root.json"],
        ["aicos_runtime/a.py", "policies/p.json", "trust/root.json"],
    )
    assert r.status == TriState.PASS

def test_unexpected_file_blocks():
    r = evaluate_closed_world_manifest(
        ["aicos_runtime/a.py"],
        ["aicos_runtime/a.py", "aicos_runtime/extra.py"],
    )
    assert r.status == TriState.FAIL
    assert r.reason == "UNEXPECTED_ARTIFACT_PRESENT"

def test_missing_file_blocks():
    r = evaluate_closed_world_manifest(
        ["aicos_runtime/a.py", "policies/p.json"],
        ["aicos_runtime/a.py"],
    )
    assert r.status == TriState.FAIL
    assert r.reason == "EXPECTED_ARTIFACT_MISSING"

def test_outside_closed_world_blocks():
    r = evaluate_closed_world_manifest(
        ["aicos_runtime/a.py"],
        ["aicos_runtime/a.py", "tmp/evil.py"],
    )
    assert r.status == TriState.FAIL
    assert r.reason == "PATH_OUTSIDE_CLOSED_WORLD"
