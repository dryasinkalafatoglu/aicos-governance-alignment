from datetime import datetime, timezone, timedelta
from aicos_runtime.common import TriState
from aicos_runtime.authority.action_authority import AuthorityGrant, evaluate_action_authority

T0 = datetime(2026,1,1,tzinfo=timezone.utc)

def grant(**kw):
    d = dict(
        principal_id="p1",
        actions={"approve_credit","hold_credit"},
        valid_from=T0 - timedelta(days=1),
        valid_until=T0 + timedelta(days=1),
        revoked_at=None,
    )
    d.update(kw)
    return AuthorityGrant(**d)

def test_authorized_action_passes():
    assert evaluate_action_authority(grant(), "p1", "approve_credit", T0).status == TriState.PASS

def test_wrong_principal_blocks():
    assert evaluate_action_authority(grant(), "p2", "approve_credit", T0).status == TriState.FAIL

def test_unauthorized_action_blocks():
    assert evaluate_action_authority(grant(), "p1", "delete_all", T0).reason == "ACTION_NOT_AUTHORIZED"

def test_revoked_authority_blocks():
    g = grant(revoked_at=T0 - timedelta(seconds=1))
    assert evaluate_action_authority(g, "p1", "approve_credit", T0).reason == "AUTHORITY_REVOKED"

def test_missing_grant_unknown():
    assert evaluate_action_authority(None, "p1", "approve_credit", T0).status == TriState.UNKNOWN
