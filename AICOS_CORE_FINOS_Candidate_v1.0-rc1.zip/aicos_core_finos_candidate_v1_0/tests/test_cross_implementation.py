import json
from pathlib import Path
import pytest

from benchmark.evaluator import evaluate_case
from benchmark.alt_verifier.evaluator_alt import evaluate_case_alt

ROOT = Path(__file__).resolve().parents[1]
CASES = json.loads((ROOT / "benchmark" / "finos_steel_thread_cases.json").read_text(encoding="utf-8"))

@pytest.mark.parametrize("case", CASES, ids=[c["case_id"] for c in CASES])
def test_reference_and_alt_verifier_agree(case):
    assert evaluate_case(case).result == evaluate_case_alt(case).result

def test_alt_verifier_is_not_marked_independent():
    provenance = json.loads((ROOT / "review" / "ALT_VERIFIER_PROVENANCE.json").read_text())
    assert provenance["independent_confirmation"] is False
    assert provenance["shared_corpus"] is True
    assert provenance["same_project_authoring_context"] is True
