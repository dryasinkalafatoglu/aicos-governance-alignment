from aicos_runtime.common import Permission, IndependenceStatus
from aicos_runtime.claims.claim_gate import ClaimEvidence, authorize_claim

def e(**kw):
    d = dict(
        evidence_level=3,
        independence=IndependenceStatus.NOT_INDEPENDENT,
        scope_valid=True,
        freshness_valid=True,
        provenance_complete=True,
        production_evidence=False,
    )
    d.update(kw)
    return ClaimEvidence(**d)

def test_cross_impl_claim_allowed_at_level_3():
    r = authorize_claim("cross_implementation_reproduced", e())
    assert r.decision == Permission.ALLOW

def test_independent_claim_blocked_when_independence_not_proven():
    r = authorize_claim("independently_validated", e(evidence_level=5))
    assert r.decision == Permission.BLOCK
    assert r.reason == "CLAIM_INDEPENDENCE_NOT_PROVEN"

def test_stronger_claim_downgraded():
    r = authorize_claim(
        "independent_rerun_completed",
        e(independence=IndependenceStatus.INDEPENDENT)
    )
    assert r.decision == Permission.DOWNGRADE
    assert r.max_authorized_claim == "cross_implementation_reproduced"

def test_production_claim_requires_production_evidence():
    r = authorize_claim(
        "production_proven",
        e(evidence_level=6, independence=IndependenceStatus.INDEPENDENT)
    )
    assert r.decision == Permission.BLOCK
    assert r.reason == "PRODUCTION_EVIDENCE_ABSENT"

def test_unknown_prerequisite_never_allows():
    r = authorize_claim("locally_tested", e(scope_valid=None))
    assert r.decision == Permission.HOLD
