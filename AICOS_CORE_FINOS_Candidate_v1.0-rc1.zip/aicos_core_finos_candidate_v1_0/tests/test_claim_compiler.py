from aicos_runtime.common import TriState, Permission
from aicos_runtime.independence.dimensions import IndependenceVector
from aicos_runtime.claims.claim_compiler import ClaimContext, compile_claim

def ctx(**kw):
    base = dict(
        independence=IndependenceVector(
            implementation=TriState.PASS,
            evaluation=TriState.FAIL,
            organizational=TriState.UNKNOWN,
            execution=TriState.UNKNOWN,
            oracle=TriState.UNKNOWN,
            trust_path=TriState.UNKNOWN,
        ),
        artifact_binding=TriState.PASS,
        corpus_binding=TriState.PASS,
        provenance=TriState.PASS,
        scope_binding=TriState.PASS,
        freshness=TriState.PASS,
        production_evidence=TriState.FAIL,
    )
    base.update(kw)
    return ClaimContext(**base)

def test_cross_implementation_after_correction_allowed():
    r = compile_claim("cross_implementation_reproduced_after_correction", ctx())
    assert r.decision == Permission.ALLOW

def test_independent_validation_blocked_when_eval_contaminated():
    r = compile_claim("independently_validated", ctx())
    assert r.decision == Permission.BLOCK
    assert r.authorized_claim == "cross_implementation_reproduced_after_correction"

def test_required_unknown_holds():
    ind = IndependenceVector(
        implementation=TriState.PASS,
        evaluation=TriState.PASS,
        organizational=TriState.PASS,
        execution=TriState.UNKNOWN,
        oracle=TriState.PASS,
        trust_path=TriState.PASS,
    )
    r = compile_claim("independently_validated", ctx(independence=ind))
    assert r.decision == Permission.HOLD

def test_production_not_inferred_from_validation():
    ind = IndependenceVector(
        implementation=TriState.PASS,
        evaluation=TriState.PASS,
        organizational=TriState.PASS,
        execution=TriState.PASS,
        oracle=TriState.PASS,
        trust_path=TriState.PASS,
    )
    r = compile_claim("production_proven", ctx(independence=ind, production_evidence=TriState.FAIL))
    assert r.decision == Permission.BLOCK
