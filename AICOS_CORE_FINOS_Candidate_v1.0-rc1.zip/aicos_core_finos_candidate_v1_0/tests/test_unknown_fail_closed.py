from datetime import datetime, timezone, timedelta
from aicos_runtime.common import TriState, Permission, IndependenceStatus
from aicos_runtime.temporal_authority.key_authority import KeyAuthorityContext, evaluate_tka
from aicos_runtime.claims.claim_gate import ClaimEvidence, authorize_claim

T0 = datetime(2026, 1, 1, tzinfo=timezone.utc)

def test_unknown_issuer_never_passes():
    ctx = KeyAuthorityContext(
        decision_effective_at=T0,
        verification_time=T0,
        key_id="k",
        issuer_id="i",
        signed_payload=b"x",
        signature=b"s",
        key_valid_from=T0-timedelta(days=1),
        key_valid_until=T0+timedelta(days=1),
        revoked_at=None,
        trust_root_version="tr",
        authority_snapshot_hash="h",
    )
    r = evaluate_tka(
        ctx,
        lambda p,s,k: True,
        lambda i,k,t: None,
        lambda v,t: True,
        lambda h: True,
    )
    assert r.status == TriState.UNKNOWN

def test_unknown_claim_provenance_never_allows():
    ev = ClaimEvidence(
        evidence_level=3,
        independence=IndependenceStatus.INDEPENDENT,
        scope_valid=True,
        freshness_valid=True,
        provenance_complete=None,
        production_evidence=False,
    )
    r = authorize_claim("cross_implementation_reproduced", ev)
    assert r.decision == Permission.HOLD
