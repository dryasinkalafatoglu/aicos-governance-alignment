from aicos_runtime.common import TriState
from aicos_runtime.independence.dimensions import IndependenceContext, evaluate_independence

def test_corpus_correction_fails_evaluation_not_implementation():
    v = evaluate_independence(IndependenceContext(
        different_implementation=True,
        corpus_influenced_correction=True,
        different_organization=None,
        different_operator=None,
        different_environment=None,
        independent_oracle=None,
        independent_trust_path=None,
    ))
    assert v.implementation == TriState.PASS
    assert v.evaluation == TriState.FAIL

def test_shared_operator_does_not_erase_implementation_diversity():
    v = evaluate_independence(IndependenceContext(
        different_implementation=True,
        corpus_influenced_correction=False,
        different_organization=True,
        different_operator=False,
        different_environment=True,
        independent_oracle=True,
        independent_trust_path=True,
    ))
    assert v.implementation == TriState.PASS
    assert v.execution == TriState.FAIL

def test_unknowns_remain_unknown():
    v = evaluate_independence(IndependenceContext(
        different_implementation=None,
        corpus_influenced_correction=None,
        different_organization=None,
        different_operator=None,
        different_environment=None,
        independent_oracle=None,
        independent_trust_path=None,
    ))
    assert all(x == TriState.UNKNOWN for x in (
        v.implementation, v.evaluation, v.organizational,
        v.execution, v.oracle, v.trust_path
    ))
