import copy, json
from pathlib import Path
from aicos_runtime.common import TriState
from aicos_runtime.finos.manifest_validator import validate_review_manifest

ROOT = Path(__file__).resolve().parents[1]
BASE = json.loads((ROOT/".well-known/governance-layer-manifest.json").read_text())

def bad(mutator):
    m = copy.deepcopy(BASE)
    mutator(m)
    return validate_review_manifest(m)

def test_missing_subject_fails():
    assert bad(lambda m: m.pop("subject")).status == TriState.FAIL

def test_wrong_product_role_fails():
    assert bad(lambda m: m["subject"].__setitem__("product_role","Decision Authority Layer")).status == TriState.FAIL

def test_unknown_pass_true_fails():
    assert bad(lambda m: m["assurance_logic"].__setitem__("unknown_is_pass",True)).status == TriState.FAIL

def test_replay_as_evidence_true_fails():
    assert bad(lambda m: m["replay_contract"].__setitem__("replay_is_evidence",True)).status == TriState.FAIL

def test_agreement_as_independence_true_fails():
    assert bad(lambda m: m["verifier_independence"].__setitem__("agreement_implies_independence",True)).status == TriState.FAIL

def test_corpus_correction_as_independent_true_fails():
    assert bad(lambda m: m["verifier_independence"].__setitem__("corpus_influenced_correction_is_independent_confirmation",True)).status == TriState.FAIL

def test_glm_formal_conformance_true_fails():
    assert bad(lambda m: m["glm_interoperability_candidate"].__setitem__("formal_conformance_claimed",True)).status == TriState.FAIL

def test_official_finos_schema_claim_true_fails():
    assert bad(lambda m: m["glm_interoperability_candidate"].__setitem__("official_finos_schema_claimed",True)).status == TriState.FAIL

def test_reviewability_only_layer_fails():
    assert bad(lambda m: m["glm_interoperability_candidate"].__setitem__("layer_type_candidate","reviewability")).status == TriState.FAIL

def test_post_bind_only_timing_fails():
    assert bad(lambda m: m["glm_interoperability_candidate"]["timing_axis"].__setitem__("positions",["post_bind"])).status == TriState.FAIL

def test_missing_decision_time_binding_fails():
    assert bad(lambda m: m["timing_model"].__setitem__("decision_effective_time_required",False)).status == TriState.FAIL

def test_missing_license_status_fails():
    assert bad(lambda m: m["licensing"].__setitem__("status","")).status == TriState.FAIL
