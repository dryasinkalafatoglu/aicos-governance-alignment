from aicos_runtime.certificates.release_envelope import ReleaseEvidenceEnvelope, verify_envelope

def env():
    return ReleaseEvidenceEnvelope(
        release_id="R1",
        artifact_hash="a",
        manifest_hash="m",
        evidence_graph_hash="e",
        policy_hash="p",
        trust_root_hash="t",
        claims_hash="c",
    )

def test_envelope_hash_verifies():
    e = env()
    assert verify_envelope(e.envelope_hash(), e)

def test_policy_change_breaks_envelope():
    e = env()
    h = e.envelope_hash()
    e2 = ReleaseEvidenceEnvelope("R1","a","m","e","p2","t","c")
    assert not verify_envelope(h, e2)

def test_claim_change_breaks_envelope():
    e = env()
    h = e.envelope_hash()
    e2 = ReleaseEvidenceEnvelope("R1","a","m","e","p","t","c2")
    assert not verify_envelope(h, e2)
