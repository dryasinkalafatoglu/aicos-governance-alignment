import json
from pathlib import Path
import pytest
from benchmark.evaluator import evaluate_case

ROOT = Path(__file__).resolve().parents[1]
CASES = json.loads((ROOT / "benchmark" / "finos_steel_thread_cases.json").read_text(encoding="utf-8"))

@pytest.mark.parametrize("case", CASES, ids=[c["case_id"] for c in CASES])
def test_finos_steel_thread_case(case):
    observed = evaluate_case(case).result
    assert observed == case["expected"], (
        f'{case["case_id"]} family={case["family"]}: '
        f'expected {case["expected"]}, observed {observed}'
    )
