from aicos_runtime.common import TriState
from aicos_runtime.evidence.lineage_graph import EvidenceNode, EvidenceEdge, EvidenceGraph
from aicos_runtime.independence.contamination import evaluation_independence_from_graph

def test_content_hash_changes_when_payload_changes():
    a = EvidenceNode("CORPUS", {"name":"c","v":1})
    b = EvidenceNode("CORPUS", {"name":"c","v":2})
    assert a.node_id != b.node_id

def test_graph_hash_stable_for_same_content():
    a = EvidenceNode("ARTIFACT", {"sha":"a"})
    b = EvidenceNode("CORPUS", {"sha":"c"})
    g1 = EvidenceGraph([a,b],[EvidenceEdge(a.node_id,"EVALUATES",b.node_id)])
    g2 = EvidenceGraph([b,a],[EvidenceEdge(a.node_id,"EVALUATES",b.node_id)])
    assert g1.graph_hash() == g2.graph_hash()

def test_cycle_detected():
    a = EvidenceNode("A", {"x":1})
    b = EvidenceNode("B", {"x":2})
    g = EvidenceGraph([a,b],[
        EvidenceEdge(a.node_id,"DERIVED_FROM",b.node_id),
        EvidenceEdge(b.node_id,"DERIVED_FROM",a.node_id),
    ])
    assert g.has_cycle()

def test_corpus_influence_fails_evaluation_independence_only():
    impl = EvidenceNode("IMPLEMENTATION", {"name":"v2"})
    corpus = EvidenceNode("CORPUS", {"name":"farley"})
    g = EvidenceGraph([impl, corpus],[
        EvidenceEdge(impl.node_id,"INFLUENCED_BY",corpus.node_id)
    ])
    assert evaluation_independence_from_graph(g, impl.node_id, corpus.node_id) == TriState.FAIL

def test_missing_lineage_is_unknown():
    impl = EvidenceNode("IMPLEMENTATION", {"name":"v2"})
    g = EvidenceGraph([impl],[])
    assert evaluation_independence_from_graph(g, impl.node_id, "missing") == TriState.UNKNOWN
