from aicos_runtime.contagion.evidence_contagion import EvidenceNode, EvidenceDependencyGraph, NodeStatus

def test_revocation_propagates_across_evidence_graph():
    g = EvidenceDependencyGraph([
        EvidenceNode("trust-root-v1", set()),
        EvidenceNode("verifier-evidence", {"trust-root-v1"}),
        EvidenceNode("independent-rerun", {"verifier-evidence"}),
    ])
    affected = g.revoke("trust-root-v1")
    assert set(affected) == {"trust-root-v1", "verifier-evidence", "independent-rerun"}
    assert g.nodes["independent-rerun"].status == NodeStatus.REVOKED

def test_unrelated_evidence_survives():
    g = EvidenceDependencyGraph([
        EvidenceNode("a", set()),
        EvidenceNode("b", {"a"}),
        EvidenceNode("c", set()),
    ])
    g.revoke("a")
    assert g.nodes["c"].status == NodeStatus.VALID
