from aicos_runtime.common import IndependenceStatus
from aicos_runtime.independence.verifier_independence import IndependenceEvidence, evaluate_independence

def base(**kw):
    d = dict(
        different_codebase=True,
        independent_operator=True,
        independent_environment=True,
        shared_source_code=False,
        shared_test_oracle=False,
        shared_operator=False,
        shared_environment=False,
        expected_results_disclosed=False,
        corpus_influenced_correction=False,
        shared_trust_root=False,
    )
    d.update(kw)
    return IndependenceEvidence(**d)

def test_independent_path_passes():
    assert evaluate_independence(base()).status == IndependenceStatus.INDEPENDENT

def test_corpus_influenced_correction_not_independent():
    r = evaluate_independence(base(corpus_influenced_correction=True))
    assert r.status == IndependenceStatus.NOT_INDEPENDENT
    assert r.reason == "CORPUS_INFLUENCED_IMPLEMENTATION"

def test_missing_provenance_unknown():
    r = evaluate_independence(base(independent_environment=None))
    assert r.status == IndependenceStatus.UNKNOWN
