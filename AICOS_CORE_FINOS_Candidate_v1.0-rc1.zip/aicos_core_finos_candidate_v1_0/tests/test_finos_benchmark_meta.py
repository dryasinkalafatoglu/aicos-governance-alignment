import json
from pathlib import Path
from collections import Counter

ROOT = Path(__file__).resolve().parents[1]
CASES = json.loads((ROOT / "benchmark" / "finos_steel_thread_cases.json").read_text())

def test_benchmark_has_exactly_100_cases():
    assert len(CASES) == 100

def test_benchmark_has_10_balanced_families():
    counts = Counter(c["family"] for c in CASES)
    assert len(counts) == 10
    assert set(counts.values()) == {10}

def test_benchmark_has_90_unsafe_and_10_clean_controls():
    assert sum(c["expected"] == "BLOCK" for c in CASES) == 90
    assert sum(c["expected"] == "PASS" for c in CASES) == 10

def test_case_ids_unique():
    ids = [c["case_id"] for c in CASES]
    assert len(ids) == len(set(ids))

def test_clean_controls_are_not_mutated():
    clean = [c for c in CASES if c["family"] == "clean_control"]
    for c in clean:
        assert c["evidence_fresh"] is True
        assert c["mandatory_evidence_present"] is True
        assert c["authority_valid"] is True
        assert c["authority_revoked"] is False
        assert c["dependency_healthy"] is True
        assert c["policy_hash_match"] is True
        assert c["trust_root_match"] is True
        assert c["tool_binding_match"] is True
        assert c["receipt_integrity"] is True
