import hashlib, hmac
from aicos_runtime.common import TriState
from aicos_runtime.release.detached_verification import verify_hmac_detached

def test_valid_detached_signature_passes():
    key = b"secret"
    payload = b"artifact"
    sig = hmac.new(key, payload, hashlib.sha256).hexdigest()
    assert verify_hmac_detached(payload, sig, key).status == TriState.PASS

def test_payload_mutation_blocks():
    key = b"secret"
    sig = hmac.new(key, b"artifact", hashlib.sha256).hexdigest()
    assert verify_hmac_detached(b"artifact2", sig, key).status == TriState.FAIL

def test_missing_signature_inputs_unknown():
    assert verify_hmac_detached(b"", "", b"").status == TriState.UNKNOWN
