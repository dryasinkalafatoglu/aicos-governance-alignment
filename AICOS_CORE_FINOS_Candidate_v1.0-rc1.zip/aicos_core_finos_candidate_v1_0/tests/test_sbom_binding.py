from aicos_runtime.common import TriState
from aicos_runtime.provenance.sbom_binding import evaluate_sbom_binding

def test_exact_sbom_binding_passes():
    r = evaluate_sbom_binding({"a":"h1","b":"h2"}, {"a":"h1","b":"h2"})
    assert r.status == TriState.PASS

def test_component_hash_mismatch_fails():
    r = evaluate_sbom_binding({"a":"h1"}, {"a":"hX"})
    assert r.status == TriState.FAIL
    assert "HASH_MISMATCH:a" in r.mismatches

def test_unexpected_component_fails():
    r = evaluate_sbom_binding({"a":"h1"}, {"a":"h1","b":"h2"})
    assert r.status == TriState.FAIL
    assert "UNEXPECTED:b" in r.mismatches

def test_unknown_observed_sbom_never_passes():
    r = evaluate_sbom_binding({"a":"h1"}, None)
    assert r.status == TriState.UNKNOWN
