from aicos_runtime.certificates.evidence_certificate import EvidenceClaimCertificate, verify_certificate_binding

def cert():
    return EvidenceClaimCertificate(
        release_id="AICOS-CORE-v0.x",
        artifact_hash="a1",
        manifest_hash="m1",
        evidence_graph_hash="e1",
        authorized_claims=["locally_tested"],
        blocked_claims=[{"claim":"independently_validated","reason":"INDEPENDENCE_NOT_PROVEN"}],
        revoked_claims=[],
    )

def test_binding_passes_for_exact_release():
    c = cert()
    assert verify_certificate_binding(c, "a1", "m1", "e1")

def test_artifact_tamper_blocks():
    c = cert()
    assert not verify_certificate_binding(c, "a2", "m1", "e1")

def test_claim_set_affects_certificate_hash():
    c1 = cert()
    c2 = EvidenceClaimCertificate(
        release_id=c1.release_id,
        artifact_hash=c1.artifact_hash,
        manifest_hash=c1.manifest_hash,
        evidence_graph_hash=c1.evidence_graph_hash,
        authorized_claims=["locally_tested", "cross_implementation_reproduced"],
        blocked_claims=c1.blocked_claims,
        revoked_claims=[],
    )
    assert c1.certificate_hash() != c2.certificate_hash()
