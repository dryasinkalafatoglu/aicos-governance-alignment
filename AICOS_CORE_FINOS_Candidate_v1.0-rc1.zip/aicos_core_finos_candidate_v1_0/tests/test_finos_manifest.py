import json
from pathlib import Path
from aicos_runtime.common import TriState
from aicos_runtime.finos.manifest_validator import validate_review_manifest

ROOT = Path(__file__).resolve().parents[1]
MANIFEST_PATH = ROOT / ".well-known" / "governance-layer-manifest.json"

def load():
    return json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))

def test_manifest_json_parses():
    assert isinstance(load(), dict)

def test_manifest_validator_passes():
    assert validate_review_manifest(load()).status == TriState.PASS

def test_canonical_path_is_well_known():
    assert load()["canonical_path"] == "/.well-known/governance-layer-manifest.json"

def test_product_role_is_decision_assurance_runtime():
    assert load()["subject"]["product_role"] == "Decision Assurance Runtime"

def test_unknown_is_not_pass():
    assert load()["assurance_logic"]["unknown_is_pass"] is False

def test_replay_is_not_evidence():
    assert load()["replay_contract"]["replay_is_evidence"] is False

def test_agreement_not_independence():
    assert load()["verifier_independence"]["agreement_implies_independence"] is False

def test_corpus_correction_not_independent_confirmation():
    assert load()["verifier_independence"]["corpus_influenced_correction_is_independent_confirmation"] is False

def test_glm_mapping_is_explicitly_experimental():
    assert load()["glm_interoperability_candidate"]["status"] == "EXPERIMENTAL_MAPPING_ONLY"

def test_glm_formal_conformance_not_claimed():
    assert load()["glm_interoperability_candidate"]["formal_conformance_claimed"] is False

def test_glm_official_finos_schema_not_claimed():
    assert load()["glm_interoperability_candidate"]["official_finos_schema_claimed"] is False

def test_glm_layer_type_candidate_is_cross_cutting():
    assert load()["glm_interoperability_candidate"]["layer_type_candidate"] == "cross_cutting"

def test_timing_spans_pre_at_post_and_closure():
    p = set(load()["glm_interoperability_candidate"]["timing_axis"]["positions"])
    assert {"pre_bind","at_bind","post_bind","post_closure"} <= p

def test_machine_output_is_non_binding():
    assert load()["authority_model"]["machine_output_authority"] == "NON_BINDING"

def test_institutional_authority_required():
    assert load()["authority_model"]["institutional_authority_required"] is True

def test_external_credit_write_access_disabled():
    assert load()["reference_use_case"]["external_write_access"] is False

def test_finos_formal_conformance_not_claimed():
    assert load()["external_alignment"]["finos_ai_governance_framework"]["formal_conformance_claimed"] is False

def test_independent_validation_false():
    assert load()["assurance_state"]["independent_validation"] is False

def test_production_operational_false():
    assert load()["assurance_state"]["production_operational"] is False

def test_formal_contribution_license_gate_blocks_until_declared():
    assert load()["licensing"]["submission_gate"] == "BLOCK_FORMAL_CONTRIBUTION_UNTIL_DECLARED"
