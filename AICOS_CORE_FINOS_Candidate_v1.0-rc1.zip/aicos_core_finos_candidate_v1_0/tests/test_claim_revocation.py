from aicos_runtime.claims.claim_revocation import ClaimNode, ClaimDependencyGraph, ClaimStatus

def test_evidence_revocation_propagates_to_claim():
    g = ClaimDependencyGraph([
        ClaimNode("independent_rerun_completed", {"EVIDENCE-RERUN-1"}),
    ])
    revoked = g.revoke_due_to_evidence("EVIDENCE-RERUN-1")
    assert "independent_rerun_completed" in revoked
    assert g.nodes["independent_rerun_completed"].status == ClaimStatus.REVOKED

def test_revocation_contagion_propagates_to_dependent_claim():
    g = ClaimDependencyGraph([
        ClaimNode("independent_rerun_completed", {"EVIDENCE-RERUN-1"}),
        ClaimNode("independently_validated", {"independent_rerun_completed"}),
        ClaimNode("production_proven", {"independently_validated", "EVIDENCE-PROD-1"}),
    ])
    revoked = g.revoke_due_to_evidence("EVIDENCE-RERUN-1")
    assert set(revoked) == {
        "independent_rerun_completed",
        "independently_validated",
        "production_proven",
    }

def test_unrelated_claim_not_revoked():
    g = ClaimDependencyGraph([
        ClaimNode("locally_tested", {"EVIDENCE-LOCAL-1"}),
        ClaimNode("production_proven", {"EVIDENCE-PROD-1"}),
    ])
    g.revoke_due_to_evidence("EVIDENCE-LOCAL-1")
    assert g.nodes["production_proven"].status == ClaimStatus.AUTHORIZED
