from datetime import datetime, timezone, timedelta
from aicos_runtime.common import TriState
from aicos_runtime.temporal_authority.key_authority import KeyAuthorityContext, evaluate_tka

T0 = datetime(2026, 1, 1, tzinfo=timezone.utc)

def ctx(**kw):
    base = dict(
        decision_effective_at=T0,
        verification_time=T0 + timedelta(days=30),
        key_id="k1",
        issuer_id="iss1",
        signed_payload=b"payload",
        signature=b"sig",
        key_valid_from=T0 - timedelta(days=10),
        key_valid_until=T0 + timedelta(days=10),
        revoked_at=None,
        trust_root_version="tr1",
        authority_snapshot_hash="abc",
    )
    base.update(kw)
    return KeyAuthorityContext(**base)

ok_sig = lambda p, s, k: True
ok_issuer = lambda i, k, t: True
ok_trust = lambda v, t: True
ok_snap = lambda h: True

def test_valid_signature_valid_key_pass():
    r = evaluate_tka(ctx(), ok_sig, ok_issuer, ok_trust, ok_snap)
    assert r.status == TriState.PASS

def test_expired_key_blocks():
    r = evaluate_tka(ctx(key_valid_until=T0), ok_sig, ok_issuer, ok_trust, ok_snap)
    assert r.status == TriState.FAIL
    assert r.reason == "KEY_EXPIRED_AT_DECISION_TIME"

def test_revoked_before_decision_blocks():
    r = evaluate_tka(ctx(revoked_at=T0 - timedelta(seconds=1)), ok_sig, ok_issuer, ok_trust, ok_snap)
    assert r.status == TriState.FAIL

def test_revoked_after_decision_replay_preserved():
    r = evaluate_tka(ctx(revoked_at=T0 + timedelta(days=1)), ok_sig, ok_issuer, ok_trust, ok_snap)
    assert r.status == TriState.PASS

def test_unknown_trust_root_never_passes():
    unknown_trust = lambda v, t: None
    r = evaluate_tka(ctx(), ok_sig, ok_issuer, unknown_trust, ok_snap)
    assert r.status == TriState.UNKNOWN
