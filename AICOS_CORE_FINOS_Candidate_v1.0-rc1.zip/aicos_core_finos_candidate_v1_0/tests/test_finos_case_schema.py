import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
CASES = json.loads((ROOT/"benchmark"/"finos_steel_thread_cases.json").read_text())
REQUIRED = {"case_id","family","expected","evidence_fresh","mandatory_evidence_present","authority_valid","authority_revoked","dependency_healthy","policy_hash_match","trust_root_match","tool_binding_match","receipt_integrity"}

def test_all_cases_match_declared_shape():
    for c in CASES:
        assert set(c) == REQUIRED
        assert c["expected"] in {"PASS","BLOCK","ABSTAIN"}
