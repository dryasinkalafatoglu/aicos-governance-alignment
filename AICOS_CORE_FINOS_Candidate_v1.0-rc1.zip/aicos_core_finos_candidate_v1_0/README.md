# AICOS® CORE — Decision Assurance Runtime

**Status:** experimental / externally reviewable engineering artifact  
**Primary question:** *May this specific AI- or agent-assisted decision be relied upon and executed now?*

AICOS CORE is a bounded decision-assurance runtime for high-consequence AI workflows. It is not an AI model, IAM system, API gateway, generic policy engine, governance dashboard, or audit-log product.

Its responsibility is narrow: evaluate whether the evidence, authority, temporal state, provenance, dependency health, policy binding and release state required for reliance are valid at decision time.

## Core invariants

- `Prediction != Decision`
- `Replayability != Evidence`
- `Simulation != Proof`
- `UNKNOWN != PASS`
- `ClaimStrength <= EvidenceStrength`
- `ClaimScope <= EvidenceScope`
- `InformationUsed(t) ⊆ InformationAvailableAt(t)`
- cryptographic validity does not by itself establish decision authority
- agreement does not by itself establish verifier independence
- no trust claim survives revocation of the evidence that authorized it

## Canonical reliance states

`PASS / HOLD / BLOCK / ABSTAIN`

These states concern permission to rely on a decision under the configured assurance contract. They are not statements that an AI model is globally correct or safe.

## FINOS-facing scope

This repository contains an experimental finance-oriented steel thread and machine-readable governance boundary intended for technical scrutiny against relevant FINOS AI Governance Framework concepts.

The current public FINOS AI Governance Framework includes, among other relevant materials:

- Credit Risk Analysis use case (`uc-1`)
- Agent Action Authorization Bypass (`ri-24`)
- Non-Deterministic Behaviour (`ri-6`)
- Data Quality and Drift (`ri-19`)
- AI Model Version Pinning (`mi-10`)
- AI System Observability (`mi-4`)
- System Acceptance Testing (`mi-5`)
- Human Feedback Loop (`mi-11`)

AICOS does **not** claim FINOS endorsement, certification, adoption, formal conformance, or independent validation.

See `FINOS_ALIGNMENT.md`.

## Engineering evidence in this package

The package contains executable controls for:

- decision-time key validity and revocation
- decision-time action authority
- verifier-independence contamination
- evidence-bound claim authorization
- claim revocation propagation
- deterministic replay snapshot binding
- decision-time health binding
- closed-world release manifests
- policy effective-date binding
- SBOM/component provenance binding
- runtime environment integrity
- detached artifact verification
- release evidence envelope binding

Run:

```bash
python -m pytest -q
```

The test result is local engineering evidence only. Passing local tests does not establish external reproduction, independent validation, certification, or production proof.

## External reproduction

Use `REPRODUCTION_PROTOCOL.md` and `FINOS_REVIEW_PACKET.md`.

The reviewer is explicitly asked to distinguish:

`first-party tested != externally reproduced != independently validated != production-proven`

## Machine-readable governance boundary

Canonical repository artifact:

`.well-known/governance-layer-manifest.json`

The `glm_interoperability_candidate` section is an **experimental mapping candidate** informed by external technical boundary feedback. It is not represented as an official FINOS schema or as GLM conformance.

## Licensing gate

Before any formal upstream contribution, the repository owner must explicitly choose and publish the applicable license and satisfy any FINOS contributor-agreement requirements. This package does not silently make that legal choice for the owner.

## Founder attribution

Yasin Kalafatoğlu — Founder, AICOS®

## FINOS steel-thread benchmark

`benchmark/` now contains 100 deterministic synthetic finance-facing cases: 90 deliberately unsafe cases and 10 clean controls across ten control families. The benchmark is designed for falsification of fail-closed behavior and remains explicitly non-production evidence.

## Cross-implementation check

A second, differently structured verifier implementation is included for differential testing. It shares the same project/corpus and therefore is explicitly **not** treated as independent validation.

## v1.0 candidate — typed independence and claim compiler

Verifier independence is now modeled by typed PASS/FAIL/UNKNOWN dimensions rather than a single coarse state. A content-addressed evidence-lineage graph and policy-driven claim compiler prevent corpus-driven verifier correction from being misrepresented as independent validation.
