# AICOS CORE — FINOS External Reproduction & Falsification Packet

## Reviewer objective

Try to falsify the bounded claim:

> Given the supplied deterministic fixtures and bound policy/evidence/authority state, the AICOS reference controls fail closed on the specified unsafe conditions and reproduce the same decision result against the same bound snapshot.

Do not test "whether AICOS is generally safe." That claim is not made.

## Minimum reviewer procedure

1. Use a clean Python 3.10+ environment.
2. Record OS, Python and pytest versions.
3. Record the repository commit or archive SHA-256.
4. Run `python -m pytest -q`.
5. Re-run the complete suite at least three times.
6. Mutate at least one artifact in each class:
   - policy hash
   - trust root
   - evidence snapshot
   - action authority
   - key validity / revocation
   - runtime path
   - SBOM component hash
   - claim evidence snapshot
7. Confirm each mutation either fails, blocks, holds, or produces a documented UNKNOWN state.
8. Record any case that produces an unintended PASS.
9. Record whether the reviewer/implementation was influenced by expected results or corpus-driven corrections.

## Independence declaration

A second implementation is not automatically independent.

The reviewer must record:
- shared source code: yes/no/unknown
- shared test oracle: yes/no/unknown
- expected outputs disclosed before implementation: yes/no/unknown
- corpus-driven correction occurred: yes/no/unknown
- same operator: yes/no/unknown
- same execution environment: yes/no/unknown

If independence provenance is incomplete, the result may be described as external reproduction, but must not be upgraded to independent validation.

## Failure conditions

Review result is `FAILED` if:
- any mandatory unsafe fixture results in an unintended PASS;
- a changed bound snapshot is accepted as the original replay;
- an expired/revoked authority is accepted at decision time;
- UNKNOWN mandatory state becomes PASS;
- evidence revocation leaves a dependent strong claim active;
- a release with broken artifact/manifest/replay/claim integrity is authorized.

`NOT REPRODUCIBLE` is distinct from `FAILED` and should be used when the supplied package cannot be executed as documented.

## Claim boundary

Successful reproduction supports only the scoped implementation behavior observed under the recorded environment and corpus.

## Supplied deterministic corpus

The package includes `benchmark/finos_steel_thread_cases.json` with 100 inspectable synthetic cases. Reviewers are encouraged to add new adversarial cases rather than only replay supplied expected outputs.


## Cross-implementation consistency check

The package contains a second verifier implementation with a distinct code path. It is compared against the reference implementation on all 100 supplied cases.

This does **not** constitute independent confirmation because the alternate verifier shares the project authoring context, corpus and test oracle. Its purpose is to reduce single-implementation dependence before an external verifier is introduced.

A reviewer can run:

```bash
cd benchmark
python run_cross_implementation.py
```
