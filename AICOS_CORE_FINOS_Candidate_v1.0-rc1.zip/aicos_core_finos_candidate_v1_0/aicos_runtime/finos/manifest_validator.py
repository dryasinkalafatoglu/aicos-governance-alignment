from dataclasses import dataclass
from typing import Any, Dict, Tuple
from aicos_runtime.common import TriState

@dataclass(frozen=True)
class ManifestValidationResult:
    status: TriState
    reason: str
    errors: Tuple[str, ...] = ()

REQUIRED_TOP = {
    "schema_version",
    "manifest_type",
    "manifest_version",
    "canonical_path",
    "status",
    "subject",
    "scope",
    "authority_model",
    "assurance_logic",
    "timing_model",
    "replay_contract",
    "verifier_independence",
    "claim_boundary",
    "consumer_constraints",
    "forbidden_interpretations",
    "composition",
    "glm_interoperability_candidate",
    "reference_use_case",
    "external_alignment",
    "assurance_state",
    "integrity",
    "licensing",
}

def validate_review_manifest(m: Dict[str, Any]) -> ManifestValidationResult:
    errors = []

    missing = sorted(REQUIRED_TOP - set(m))
    errors.extend(f"MISSING:{x}" for x in missing)

    if m.get("canonical_path") != "/.well-known/governance-layer-manifest.json":
        errors.append("CANONICAL_PATH_INVALID")

    subject = m.get("subject") or {}
    if subject.get("product_role") != "Decision Assurance Runtime":
        errors.append("PRODUCT_ROLE_BOUNDARY_INVALID")

    assurance = m.get("assurance_logic") or {}
    if assurance.get("unknown_is_pass") is not False:
        errors.append("UNKNOWN_MUST_NOT_PASS")

    timing = m.get("timing_model") or {}
    if timing.get("decision_effective_time_required") is not True:
        errors.append("DECISION_TIME_BINDING_REQUIRED")

    replay = m.get("replay_contract") or {}
    if replay.get("replay_is_evidence") is not False:
        errors.append("REPLAY_MUST_NOT_BE_EVIDENCE")

    ind = m.get("verifier_independence") or {}
    if ind.get("agreement_implies_independence") is not False:
        errors.append("AGREEMENT_MUST_NOT_IMPLY_INDEPENDENCE")
    if ind.get("corpus_influenced_correction_is_independent_confirmation") is not False:
        errors.append("CORPUS_CORRECTION_MUST_NOT_COUNT_AS_INDEPENDENT")

    glm = m.get("glm_interoperability_candidate") or {}
    if glm.get("formal_conformance_claimed") is not False:
        errors.append("GLM_FORMAL_CONFORMANCE_MUST_NOT_BE_CLAIMED")
    if glm.get("official_finos_schema_claimed") is not False:
        errors.append("UNVERIFIED_OFFICIAL_SCHEMA_CLAIM")
    if glm.get("layer_type_candidate") != "cross_cutting":
        errors.append("GLM_LAYER_TYPE_BOUNDARY")
    positions = ((glm.get("timing_axis") or {}).get("positions") or [])
    for required in ("pre_bind", "at_bind", "post_bind", "post_closure"):
        if required not in positions:
            errors.append(f"TIMING_POSITION_MISSING:{required}")

    claims = m.get("claim_boundary") or {}
    prohibited = " ".join(claims.get("prohibited_claims") or []).lower()
    for token in ("finos", "independently validated", "production-proven"):
        if token not in prohibited:
            errors.append(f"PROHIBITED_CLAIM_BOUNDARY_MISSING:{token}")

    licensing = m.get("licensing") or {}
    if not licensing.get("status"):
        errors.append("LICENSING_STATUS_MISSING")

    if errors:
        return ManifestValidationResult(TriState.FAIL, "MANIFEST_REVIEW_BOUNDARY_INVALID", tuple(errors))
    return ManifestValidationResult(TriState.PASS, "MANIFEST_REVIEW_BOUNDARY_VALID")
