import hashlib
import hmac
from dataclasses import dataclass
from aicos_runtime.common import TriState

@dataclass(frozen=True)
class DetachedVerificationResult:
    status: TriState
    reason: str

def verify_hmac_detached(payload: bytes, signature_hex: str, key: bytes) -> DetachedVerificationResult:
    if not payload or not signature_hex or not key:
        return DetachedVerificationResult(TriState.UNKNOWN, "DETACHED_SIGNATURE_INPUT_INCOMPLETE")

    expected = hmac.new(key, payload, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, signature_hex):
        return DetachedVerificationResult(TriState.FAIL, "DETACHED_SIGNATURE_INVALID")

    return DetachedVerificationResult(TriState.PASS, "DETACHED_SIGNATURE_VALID")
