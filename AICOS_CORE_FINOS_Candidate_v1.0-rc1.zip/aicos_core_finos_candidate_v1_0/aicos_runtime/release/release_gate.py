from dataclasses import dataclass
from typing import Dict
from aicos_runtime.common import TriState, Permission

@dataclass(frozen=True)
class ReleaseGateResult:
    status: Permission
    reason: str

def evaluate_release_gate(
    artifact_integrity: TriState,
    manifest_integrity: TriState,
    test_status: TriState,
    replay_status: TriState,
    claim_gate_status: Permission,
) -> ReleaseGateResult:
    states: Dict[str, TriState] = {
        "ARTIFACT_INTEGRITY": artifact_integrity,
        "MANIFEST_INTEGRITY": manifest_integrity,
        "TEST_STATUS": test_status,
        "REPLAY_STATUS": replay_status,
    }

    for name, state in states.items():
        if state == TriState.FAIL:
            return ReleaseGateResult(Permission.BLOCK, f"{name}_FAIL")
        if state == TriState.UNKNOWN:
            return ReleaseGateResult(Permission.HOLD, f"{name}_UNKNOWN")

    if claim_gate_status == Permission.BLOCK:
        return ReleaseGateResult(Permission.BLOCK, "CLAIM_GATE_BLOCK")
    if claim_gate_status in (Permission.HOLD, Permission.DOWNGRADE):
        return ReleaseGateResult(Permission.HOLD, "CLAIM_GATE_NOT_FULLY_AUTHORIZED")

    return ReleaseGateResult(Permission.ALLOW, "RELEASE_AUTHORIZED")
