from dataclasses import dataclass
from typing import Optional
from aicos_runtime.common import Permission, IndependenceStatus
from aicos_runtime.claims.claim_lattice import CLAIM_LEVELS, strongest_claim_at_or_below

@dataclass(frozen=True)
class ClaimEvidence:
    evidence_level: int
    independence: IndependenceStatus
    scope_valid: Optional[bool]
    freshness_valid: Optional[bool]
    provenance_complete: Optional[bool]
    production_evidence: bool = False

@dataclass(frozen=True)
class ClaimDecision:
    decision: Permission
    requested_claim: str
    max_authorized_claim: str
    reason: str

def authorize_claim(requested_claim: str, evidence: ClaimEvidence) -> ClaimDecision:
    if requested_claim not in CLAIM_LEVELS:
        return ClaimDecision(Permission.BLOCK, requested_claim, strongest_claim_at_or_below(evidence.evidence_level), "UNKNOWN_CLAIM")

    max_claim = strongest_claim_at_or_below(evidence.evidence_level)

    if evidence.scope_valid is None or evidence.freshness_valid is None or evidence.provenance_complete is None:
        return ClaimDecision(Permission.HOLD, requested_claim, max_claim, "CLAIM_PREREQUISITE_UNKNOWN")

    if not evidence.scope_valid:
        return ClaimDecision(Permission.BLOCK, requested_claim, max_claim, "CLAIM_SCOPE_EXCEEDS_EVIDENCE_SCOPE")

    if not evidence.freshness_valid:
        return ClaimDecision(Permission.BLOCK, requested_claim, max_claim, "CLAIM_EVIDENCE_STALE")

    if not evidence.provenance_complete:
        return ClaimDecision(Permission.BLOCK, requested_claim, max_claim, "CLAIM_PROVENANCE_INCOMPLETE")

    required = CLAIM_LEVELS[requested_claim]
    if required >= CLAIM_LEVELS["independent_rerun_completed"] and evidence.independence != IndependenceStatus.INDEPENDENT:
        return ClaimDecision(Permission.BLOCK, requested_claim, max_claim, "CLAIM_INDEPENDENCE_NOT_PROVEN")

    if requested_claim == "production_proven" and not evidence.production_evidence:
        return ClaimDecision(Permission.BLOCK, requested_claim, max_claim, "PRODUCTION_EVIDENCE_ABSENT")

    if required > evidence.evidence_level:
        return ClaimDecision(Permission.DOWNGRADE, requested_claim, max_claim, "CLAIM_STRENGTH_EXCEEDS_EVIDENCE")

    return ClaimDecision(Permission.ALLOW, requested_claim, requested_claim, "CLAIM_AUTHORIZED")
