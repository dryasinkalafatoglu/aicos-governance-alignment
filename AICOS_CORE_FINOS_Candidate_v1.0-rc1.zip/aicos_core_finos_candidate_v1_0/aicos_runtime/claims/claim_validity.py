from dataclasses import dataclass
from datetime import datetime
from typing import Optional
from aicos_runtime.common import TriState

@dataclass(frozen=True)
class ClaimValidityWindow:
    valid_from: datetime
    valid_until: Optional[datetime]
    evidence_snapshot_hash: Optional[str]

@dataclass(frozen=True)
class ClaimValidityResult:
    status: TriState
    reason: str

def evaluate_claim_validity(window: ClaimValidityWindow, now: datetime, current_evidence_snapshot_hash: Optional[str]) -> ClaimValidityResult:
    if now < window.valid_from:
        return ClaimValidityResult(TriState.FAIL, "CLAIM_NOT_YET_VALID")

    if window.valid_until is not None and now >= window.valid_until:
        return ClaimValidityResult(TriState.FAIL, "CLAIM_EXPIRED")

    if window.evidence_snapshot_hash is None or current_evidence_snapshot_hash is None:
        return ClaimValidityResult(TriState.UNKNOWN, "EVIDENCE_SNAPSHOT_UNKNOWN")

    if window.evidence_snapshot_hash != current_evidence_snapshot_hash:
        return ClaimValidityResult(TriState.FAIL, "CLAIM_EVIDENCE_SNAPSHOT_MISMATCH")

    return ClaimValidityResult(TriState.PASS, "CLAIM_TEMPORALLY_VALID")
