from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Set

class ClaimStatus(str, Enum):
    AUTHORIZED = "AUTHORIZED"
    HOLD = "HOLD"
    BLOCKED = "BLOCKED"
    REVOKED = "REVOKED"

@dataclass
class ClaimNode:
    claim: str
    depends_on: Set[str]
    status: ClaimStatus = ClaimStatus.AUTHORIZED

class ClaimDependencyGraph:
    def __init__(self, nodes: List[ClaimNode]):
        self.nodes: Dict[str, ClaimNode] = {n.claim: n for n in nodes}

    def revoke_due_to_evidence(self, evidence_id: str) -> List[str]:
        revoked = []
        changed = True
        invalid = {evidence_id}
        while changed:
            changed = False
            for node in self.nodes.values():
                if node.status == ClaimStatus.REVOKED:
                    invalid.add(node.claim)
                    continue
                if node.depends_on & invalid:
                    node.status = ClaimStatus.REVOKED
                    revoked.append(node.claim)
                    invalid.add(node.claim)
                    changed = True
        return revoked
