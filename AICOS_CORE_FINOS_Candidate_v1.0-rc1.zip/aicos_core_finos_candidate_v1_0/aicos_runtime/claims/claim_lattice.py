CLAIM_LEVELS = {
    "design_assertion": 0,
    "implemented": 1,
    "locally_tested": 2,
    "cross_implementation_reproduced": 3,
    "independent_rerun_completed": 4,
    "independently_validated": 5,
    "production_proven": 6,
}

def strongest_claim_at_or_below(level: int) -> str:
    eligible = [(name, n) for name, n in CLAIM_LEVELS.items() if n <= level]
    return max(eligible, key=lambda x: x[1])[0]
