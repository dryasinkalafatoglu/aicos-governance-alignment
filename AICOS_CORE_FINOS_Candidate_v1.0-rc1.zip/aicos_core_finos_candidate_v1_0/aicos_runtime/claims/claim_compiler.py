from dataclasses import dataclass
from typing import Dict, Tuple
from aicos_runtime.common import TriState, Permission
from aicos_runtime.independence.dimensions import IndependenceVector

@dataclass(frozen=True)
class ClaimContext:
    independence: IndependenceVector
    artifact_binding: TriState
    corpus_binding: TriState
    provenance: TriState
    scope_binding: TriState
    freshness: TriState
    production_evidence: TriState

@dataclass(frozen=True)
class ClaimCompileResult:
    decision: Permission
    reason: str
    authorized_claim: str | None
    proof_trace: Tuple[str, ...]

POLICY: Dict[str, Dict[str, str]] = {
    "cross_implementation_reproduced_after_correction": {
        "implementation": "PASS",
        "artifact_binding": "PASS",
        "corpus_binding": "PASS",
        "provenance": "PASS",
    },
    "independent_rerun_completed": {
        "evaluation": "PASS",
        "execution": "PASS",
        "artifact_binding": "PASS",
        "corpus_binding": "PASS",
        "provenance": "PASS",
        "scope_binding": "PASS",
        "freshness": "PASS",
    },
    "independently_validated": {
        "evaluation": "PASS",
        "organizational": "PASS",
        "execution": "PASS",
        "oracle": "PASS",
        "artifact_binding": "PASS",
        "corpus_binding": "PASS",
        "provenance": "PASS",
        "scope_binding": "PASS",
        "freshness": "PASS",
    },
    "production_proven": {
        "production_evidence": "PASS",
        "artifact_binding": "PASS",
        "provenance": "PASS",
        "scope_binding": "PASS",
        "freshness": "PASS",
    },
}

SAFE_SUBSTITUTE = {
    "independently_validated": "cross_implementation_reproduced_after_correction",
    "independent_rerun_completed": "cross_implementation_reproduced_after_correction",
}

def _resolve(ctx: ClaimContext, key: str) -> TriState:
    if hasattr(ctx.independence, key):
        return getattr(ctx.independence, key)
    return getattr(ctx, key)

def compile_claim(requested: str, ctx: ClaimContext) -> ClaimCompileResult:
    if requested not in POLICY:
        return ClaimCompileResult(Permission.BLOCK, "CLAIM_TYPE_UNKNOWN", None, ())

    trace = []
    for key, required in POLICY[requested].items():
        state = _resolve(ctx, key)
        trace.append(f"{key}={state.value}")
        if state == TriState.UNKNOWN:
            return ClaimCompileResult(
                Permission.HOLD,
                f"CLAIM_POLICY_UNKNOWN:{key}",
                SAFE_SUBSTITUTE.get(requested),
                tuple(trace),
            )
        if state != TriState.PASS:
            return ClaimCompileResult(
                Permission.BLOCK,
                f"CLAIM_POLICY_UNSATISFIED:{key}",
                SAFE_SUBSTITUTE.get(requested),
                tuple(trace),
            )

    return ClaimCompileResult(Permission.ALLOW, "CLAIM_AUTHORIZED", requested, tuple(trace))
