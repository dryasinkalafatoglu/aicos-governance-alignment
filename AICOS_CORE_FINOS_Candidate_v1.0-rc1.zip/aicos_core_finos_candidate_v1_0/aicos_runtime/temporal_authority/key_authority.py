from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Callable
from aicos_runtime.common import TriState

@dataclass(frozen=True)
class KeyAuthorityContext:
    decision_effective_at: datetime
    verification_time: datetime
    key_id: str
    issuer_id: str
    signed_payload: bytes
    signature: bytes
    key_valid_from: datetime
    key_valid_until: datetime
    revoked_at: Optional[datetime]
    trust_root_version: Optional[str]
    authority_snapshot_hash: Optional[str]

@dataclass(frozen=True)
class AuthorityResult:
    status: TriState
    reason: str

def evaluate_tka(
    ctx: KeyAuthorityContext,
    verify_signature: Callable[[bytes, bytes, str], bool],
    issuer_authorized: Callable[[str, str, datetime], Optional[bool]],
    historical_trust_root_provable: Callable[[Optional[str], datetime], Optional[bool]],
    verify_authority_snapshot: Callable[[Optional[str]], Optional[bool]],
) -> AuthorityResult:
    if not verify_signature(ctx.signed_payload, ctx.signature, ctx.key_id):
        return AuthorityResult(TriState.FAIL, "SIGNATURE_INVALID")

    ia = issuer_authorized(ctx.issuer_id, ctx.key_id, ctx.decision_effective_at)
    if ia is None:
        return AuthorityResult(TriState.UNKNOWN, "ISSUER_KEY_AUTHORITY_UNKNOWN")
    if ia is False:
        return AuthorityResult(TriState.FAIL, "ISSUER_KEY_AUTHORITY_INVALID")

    if ctx.decision_effective_at < ctx.key_valid_from:
        return AuthorityResult(TriState.FAIL, "KEY_NOT_YET_VALID")

    if ctx.decision_effective_at >= ctx.key_valid_until:
        return AuthorityResult(TriState.FAIL, "KEY_EXPIRED_AT_DECISION_TIME")

    if ctx.revoked_at is not None and ctx.revoked_at <= ctx.decision_effective_at:
        return AuthorityResult(TriState.FAIL, "KEY_REVOKED_AT_DECISION_TIME")

    tr = historical_trust_root_provable(ctx.trust_root_version, ctx.decision_effective_at)
    if tr is None:
        return AuthorityResult(TriState.UNKNOWN, "TRUST_ROOT_HISTORY_UNKNOWN")
    if tr is False:
        return AuthorityResult(TriState.FAIL, "TRUST_ROOT_INVALID_AT_DECISION_TIME")

    snap = verify_authority_snapshot(ctx.authority_snapshot_hash)
    if snap is None:
        return AuthorityResult(TriState.UNKNOWN, "AUTHORITY_SNAPSHOT_UNKNOWN")
    if snap is False:
        return AuthorityResult(TriState.FAIL, "AUTHORITY_SNAPSHOT_INTEGRITY_FAILURE")

    return AuthorityResult(TriState.PASS, "DECISION_TIME_KEY_AUTHORITY_VALID")
