from dataclasses import dataclass
from aicos_runtime.common import TriState

@dataclass(frozen=True)
class IndependenceVector:
    implementation: TriState
    evaluation: TriState
    organizational: TriState
    execution: TriState
    oracle: TriState
    trust_path: TriState

@dataclass(frozen=True)
class IndependenceContext:
    different_implementation: bool | None
    corpus_influenced_correction: bool | None
    different_organization: bool | None
    different_operator: bool | None
    different_environment: bool | None
    independent_oracle: bool | None
    independent_trust_path: bool | None

def _tri(v: bool | None) -> TriState:
    if v is True:
        return TriState.PASS
    if v is False:
        return TriState.FAIL
    return TriState.UNKNOWN

def evaluate_independence(ctx: IndependenceContext) -> IndependenceVector:
    implementation = _tri(ctx.different_implementation)

    if ctx.corpus_influenced_correction is True:
        evaluation = TriState.FAIL
    elif ctx.corpus_influenced_correction is False:
        evaluation = TriState.PASS
    else:
        evaluation = TriState.UNKNOWN

    organizational = _tri(ctx.different_organization)

    if ctx.different_operator is False or ctx.different_environment is False:
        execution = TriState.FAIL
    elif ctx.different_operator is True and ctx.different_environment is True:
        execution = TriState.PASS
    else:
        execution = TriState.UNKNOWN

    oracle = _tri(ctx.independent_oracle)
    trust_path = _tri(ctx.independent_trust_path)

    return IndependenceVector(
        implementation=implementation,
        evaluation=evaluation,
        organizational=organizational,
        execution=execution,
        oracle=oracle,
        trust_path=trust_path,
    )
