from dataclasses import dataclass
from typing import Optional
from aicos_runtime.common import IndependenceStatus

@dataclass(frozen=True)
class IndependenceEvidence:
    different_codebase: Optional[bool]
    independent_operator: Optional[bool]
    independent_environment: Optional[bool]
    shared_source_code: Optional[bool]
    shared_test_oracle: Optional[bool]
    shared_operator: Optional[bool]
    shared_environment: Optional[bool]
    expected_results_disclosed: Optional[bool]
    corpus_influenced_correction: Optional[bool]
    shared_trust_root: Optional[bool]

@dataclass(frozen=True)
class IndependenceResult:
    status: IndependenceStatus
    reason: str

def evaluate_independence(e: IndependenceEvidence) -> IndependenceResult:
    contamination_flags = {
        "CORPUS_INFLUENCED_IMPLEMENTATION": e.corpus_influenced_correction,
        "SHARED_SOURCE_CODE": e.shared_source_code,
        "SHARED_TEST_ORACLE": e.shared_test_oracle,
        "SHARED_OPERATOR": e.shared_operator,
        "SHARED_EXECUTION_ENVIRONMENT": e.shared_environment,
    }
    for reason, value in contamination_flags.items():
        if value is True:
            return IndependenceResult(IndependenceStatus.NOT_INDEPENDENT, reason)

    required = [
        e.different_codebase,
        e.independent_operator,
        e.independent_environment,
    ]
    if any(v is None for v in required):
        return IndependenceResult(IndependenceStatus.UNKNOWN, "INDEPENDENCE_PROVENANCE_INCOMPLETE")

    if all(v is True for v in required):
        return IndependenceResult(IndependenceStatus.INDEPENDENT, "INDEPENDENCE_REQUIREMENTS_SATISFIED")

    return IndependenceResult(IndependenceStatus.NOT_INDEPENDENT, "INDEPENDENCE_REQUIREMENTS_NOT_SATISFIED")
