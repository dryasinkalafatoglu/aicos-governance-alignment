from aicos_runtime.common import TriState
from aicos_runtime.evidence.lineage_graph import EvidenceGraph

def evaluation_independence_from_graph(
    graph: EvidenceGraph,
    implementation_node_id: str,
    corpus_node_id: str,
) -> TriState:
    if implementation_node_id not in graph.nodes or corpus_node_id not in graph.nodes:
        return TriState.UNKNOWN
    if graph.influenced_by(implementation_node_id, corpus_node_id):
        return TriState.FAIL
    return TriState.PASS
