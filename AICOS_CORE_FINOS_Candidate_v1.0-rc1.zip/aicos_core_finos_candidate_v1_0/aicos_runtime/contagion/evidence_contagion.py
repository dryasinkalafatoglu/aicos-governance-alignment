from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Set

class NodeStatus(str, Enum):
    VALID = "VALID"
    UNKNOWN = "UNKNOWN"
    REVOKED = "REVOKED"

@dataclass
class EvidenceNode:
    node_id: str
    depends_on: Set[str]
    status: NodeStatus = NodeStatus.VALID

class EvidenceDependencyGraph:
    def __init__(self, nodes: List[EvidenceNode]):
        self.nodes: Dict[str, EvidenceNode] = {n.node_id: n for n in nodes}

    def revoke(self, node_id: str) -> List[str]:
        if node_id in self.nodes:
            self.nodes[node_id].status = NodeStatus.REVOKED

        affected = [node_id]
        invalid = {node_id}
        changed = True
        while changed:
            changed = False
            for n in self.nodes.values():
                if n.status == NodeStatus.REVOKED:
                    invalid.add(n.node_id)
                    continue
                if n.depends_on & invalid:
                    n.status = NodeStatus.REVOKED
                    affected.append(n.node_id)
                    invalid.add(n.node_id)
                    changed = True
        return affected
