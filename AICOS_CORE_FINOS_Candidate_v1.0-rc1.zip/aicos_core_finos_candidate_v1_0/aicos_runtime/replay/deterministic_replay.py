import hashlib
import json
from dataclasses import dataclass
from typing import Any, Dict

def canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

@dataclass(frozen=True)
class ReplayEnvelope:
    decision_id: str
    decision_time: str
    policy_hash: str
    trust_root_hash: str
    evidence_graph_hash: str
    input_hash: str
    expected_result: str

    def replay_contract_hash(self) -> str:
        return sha256_hex(canonical_json({
            "decision_id": self.decision_id,
            "decision_time": self.decision_time,
            "policy_hash": self.policy_hash,
            "trust_root_hash": self.trust_root_hash,
            "evidence_graph_hash": self.evidence_graph_hash,
            "input_hash": self.input_hash,
            "expected_result": self.expected_result,
        }))

def verify_replay(envelope: ReplayEnvelope, observed: Dict[str, str]) -> bool:
    required = {
        "policy_hash": envelope.policy_hash,
        "trust_root_hash": envelope.trust_root_hash,
        "evidence_graph_hash": envelope.evidence_graph_hash,
        "input_hash": envelope.input_hash,
        "result": envelope.expected_result,
    }
    return all(observed.get(k) == v for k, v in required.items())
