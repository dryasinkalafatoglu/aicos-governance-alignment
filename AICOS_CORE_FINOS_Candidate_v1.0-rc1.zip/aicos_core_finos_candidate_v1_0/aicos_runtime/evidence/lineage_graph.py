import hashlib
import json
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Set, Tuple

def canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

def content_hash(payload: Dict[str, Any]) -> str:
    return hashlib.sha256(canonical_json(payload)).hexdigest()

@dataclass(frozen=True)
class EvidenceNode:
    node_type: str
    payload: Dict[str, Any]

    @property
    def node_id(self) -> str:
        return content_hash({"node_type": self.node_type, "payload": self.payload})

@dataclass(frozen=True)
class EvidenceEdge:
    source: str
    relation: str
    target: str

class EvidenceGraph:
    def __init__(self, nodes: Iterable[EvidenceNode], edges: Iterable[EvidenceEdge]):
        self.nodes = {n.node_id: n for n in nodes}
        self.edges = list(edges)

    def graph_hash(self) -> str:
        payload = {
            "nodes": sorted(self.nodes),
            "edges": sorted(
                [{"source": e.source, "relation": e.relation, "target": e.target} for e in self.edges],
                key=lambda x: (x["source"], x["relation"], x["target"])
            ),
        }
        return content_hash(payload)

    def has_cycle(self) -> bool:
        adjacency: Dict[str, Set[str]] = {nid: set() for nid in self.nodes}
        for e in self.edges:
            if e.source in adjacency and e.target in adjacency:
                adjacency[e.source].add(e.target)

        visiting: Set[str] = set()
        visited: Set[str] = set()

        def dfs(n: str) -> bool:
            if n in visiting:
                return True
            if n in visited:
                return False
            visiting.add(n)
            for nxt in adjacency[n]:
                if dfs(nxt):
                    return True
            visiting.remove(n)
            visited.add(n)
            return False

        return any(dfs(n) for n in adjacency if n not in visited)

    def influenced_by(self, implementation_node_id: str, corpus_node_id: str) -> bool:
        return any(
            e.source == implementation_node_id
            and e.relation == "INFLUENCED_BY"
            and e.target == corpus_node_id
            for e in self.edges
        )
