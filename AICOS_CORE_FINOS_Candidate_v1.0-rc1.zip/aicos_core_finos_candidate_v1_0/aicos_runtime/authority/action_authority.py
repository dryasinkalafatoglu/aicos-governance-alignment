from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Set
from aicos_runtime.common import TriState

@dataclass(frozen=True)
class AuthorityGrant:
    principal_id: str
    actions: Set[str]
    valid_from: datetime
    valid_until: Optional[datetime]
    revoked_at: Optional[datetime]

@dataclass(frozen=True)
class AuthorityDecision:
    status: TriState
    reason: str

def evaluate_action_authority(
    grant: Optional[AuthorityGrant],
    principal_id: str,
    action: str,
    decision_time: datetime,
) -> AuthorityDecision:
    if grant is None:
        return AuthorityDecision(TriState.UNKNOWN, "AUTHORITY_GRANT_UNKNOWN")
    if grant.principal_id != principal_id:
        return AuthorityDecision(TriState.FAIL, "PRINCIPAL_MISMATCH")
    if action not in grant.actions:
        return AuthorityDecision(TriState.FAIL, "ACTION_NOT_AUTHORIZED")
    if decision_time < grant.valid_from:
        return AuthorityDecision(TriState.FAIL, "AUTHORITY_NOT_YET_EFFECTIVE")
    if grant.valid_until is not None and decision_time >= grant.valid_until:
        return AuthorityDecision(TriState.FAIL, "AUTHORITY_EXPIRED")
    if grant.revoked_at is not None and grant.revoked_at <= decision_time:
        return AuthorityDecision(TriState.FAIL, "AUTHORITY_REVOKED")
    return AuthorityDecision(TriState.PASS, "ACTION_AUTHORITY_VALID")
