from dataclasses import dataclass
from typing import Iterable, Optional, Tuple
from aicos_runtime.common import TriState

@dataclass(frozen=True)
class RuntimeIntegrityResult:
    status: TriState
    reason: str
    offending: Tuple[str, ...] = ()

def evaluate_runtime_integrity(
    sys_path: Optional[Iterable[str]],
    allowed_prefixes: Iterable[str],
    pythonpath: Optional[str],
    home: Optional[str],
    expected_home: Optional[str],
) -> RuntimeIntegrityResult:
    if sys_path is None:
        return RuntimeIntegrityResult(TriState.UNKNOWN, "SYS_PATH_UNKNOWN")

    allowed = tuple(allowed_prefixes)
    offending = tuple(sorted(
        p for p in sys_path
        if p and not any(p.startswith(prefix) for prefix in allowed)
    ))
    if offending:
        return RuntimeIntegrityResult(TriState.FAIL, "UNTRUSTED_SYS_PATH_ENTRY", offending)

    if pythonpath not in (None, ""):
        return RuntimeIntegrityResult(TriState.FAIL, "PYTHONPATH_OVERRIDE_PRESENT", (pythonpath,))

    if expected_home is not None:
        if home is None:
            return RuntimeIntegrityResult(TriState.UNKNOWN, "HOME_UNKNOWN")
        if home != expected_home:
            return RuntimeIntegrityResult(TriState.FAIL, "HOME_MISMATCH", (home,))

    return RuntimeIntegrityResult(TriState.PASS, "RUNTIME_ENVIRONMENT_VALID")
