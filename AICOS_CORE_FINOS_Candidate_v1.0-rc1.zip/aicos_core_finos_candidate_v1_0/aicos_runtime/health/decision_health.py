from dataclasses import dataclass
from datetime import datetime
from typing import Optional
from aicos_runtime.common import TriState

@dataclass(frozen=True)
class HealthContext:
    decision_time: datetime
    observed_at: datetime
    source_fresh_until: Optional[datetime]
    dependency_health: TriState
    observability_health: TriState
    provenance_health: TriState

@dataclass(frozen=True)
class HealthResult:
    status: TriState
    reason: str

def evaluate_health(ctx: HealthContext) -> HealthResult:
    if ctx.source_fresh_until is None:
        return HealthResult(TriState.UNKNOWN, "SOURCE_FRESHNESS_UNKNOWN")

    if ctx.decision_time > ctx.source_fresh_until:
        return HealthResult(TriState.FAIL, "SOURCE_STALE_AT_DECISION_TIME")

    checks = [
        ("DEPENDENCY_HEALTH", ctx.dependency_health),
        ("OBSERVABILITY_HEALTH", ctx.observability_health),
        ("PROVENANCE_HEALTH", ctx.provenance_health),
    ]
    for name, status in checks:
        if status == TriState.FAIL:
            return HealthResult(TriState.FAIL, f"{name}_FAIL")
        if status == TriState.UNKNOWN:
            return HealthResult(TriState.UNKNOWN, f"{name}_UNKNOWN")

    return HealthResult(TriState.PASS, "DECISION_TIME_HEALTH_VALID")
