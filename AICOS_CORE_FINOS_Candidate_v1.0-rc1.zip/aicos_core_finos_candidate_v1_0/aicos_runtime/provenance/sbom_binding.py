from dataclasses import dataclass
from typing import Dict, Optional, Tuple
from aicos_runtime.common import TriState

@dataclass(frozen=True)
class SBOMBindingResult:
    status: TriState
    reason: str
    mismatches: Tuple[str, ...] = ()

def evaluate_sbom_binding(
    expected_components: Dict[str, str],
    observed_components: Optional[Dict[str, str]],
) -> SBOMBindingResult:
    if observed_components is None:
        return SBOMBindingResult(TriState.UNKNOWN, "SBOM_OBSERVED_SET_UNKNOWN")

    mismatches = []
    for name, expected_hash in expected_components.items():
        observed_hash = observed_components.get(name)
        if observed_hash is None:
            mismatches.append(f"MISSING:{name}")
        elif observed_hash != expected_hash:
            mismatches.append(f"HASH_MISMATCH:{name}")

    unexpected = sorted(set(observed_components) - set(expected_components))
    mismatches.extend(f"UNEXPECTED:{name}" for name in unexpected)

    if mismatches:
        return SBOMBindingResult(TriState.FAIL, "SBOM_BINDING_MISMATCH", tuple(sorted(mismatches)))

    return SBOMBindingResult(TriState.PASS, "SBOM_BINDING_VALID")
