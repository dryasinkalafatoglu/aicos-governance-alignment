import hashlib
import json
from dataclasses import dataclass
from typing import Any

def _canon(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

@dataclass(frozen=True)
class ReleaseEvidenceEnvelope:
    release_id: str
    artifact_hash: str
    manifest_hash: str
    evidence_graph_hash: str
    policy_hash: str
    trust_root_hash: str
    claims_hash: str

    def envelope_hash(self) -> str:
        return hashlib.sha256(_canon({
            "release_id": self.release_id,
            "artifact_hash": self.artifact_hash,
            "manifest_hash": self.manifest_hash,
            "evidence_graph_hash": self.evidence_graph_hash,
            "policy_hash": self.policy_hash,
            "trust_root_hash": self.trust_root_hash,
            "claims_hash": self.claims_hash,
        })).hexdigest()

def verify_envelope(expected_hash: str, envelope: ReleaseEvidenceEnvelope) -> bool:
    return expected_hash == envelope.envelope_hash()
