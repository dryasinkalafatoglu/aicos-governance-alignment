import hashlib
import json
from dataclasses import dataclass, asdict
from typing import List, Dict, Any

def _canonical(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

@dataclass(frozen=True)
class EvidenceClaimCertificate:
    release_id: str
    artifact_hash: str
    manifest_hash: str
    evidence_graph_hash: str
    authorized_claims: List[str]
    blocked_claims: List[Dict[str, str]]
    revoked_claims: List[Dict[str, str]]

    def claim_set_hash(self) -> str:
        payload = {
            "authorized_claims": self.authorized_claims,
            "blocked_claims": self.blocked_claims,
            "revoked_claims": self.revoked_claims,
        }
        return sha256_hex(_canonical(payload))

    def certificate_hash(self) -> str:
        payload = {
            "release_id": self.release_id,
            "artifact_hash": self.artifact_hash,
            "manifest_hash": self.manifest_hash,
            "evidence_graph_hash": self.evidence_graph_hash,
            "claim_set_hash": self.claim_set_hash(),
        }
        return sha256_hex(_canonical(payload))

def verify_certificate_binding(
    cert: EvidenceClaimCertificate,
    artifact_hash: str,
    manifest_hash: str,
    evidence_graph_hash: str,
) -> bool:
    return (
        cert.artifact_hash == artifact_hash
        and cert.manifest_hash == manifest_hash
        and cert.evidence_graph_hash == evidence_graph_hash
    )
