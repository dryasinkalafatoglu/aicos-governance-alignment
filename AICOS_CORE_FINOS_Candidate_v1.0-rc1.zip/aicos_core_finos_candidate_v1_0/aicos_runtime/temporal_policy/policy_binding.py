from dataclasses import dataclass
from datetime import datetime
from typing import Optional
from aicos_runtime.common import TriState

@dataclass(frozen=True)
class PolicyBinding:
    policy_id: str
    policy_version: str
    effective_from: datetime
    effective_until: Optional[datetime]
    policy_hash: str

@dataclass(frozen=True)
class PolicyBindingResult:
    status: TriState
    reason: str

def evaluate_policy_at_decision_time(binding: PolicyBinding, decision_time: datetime) -> PolicyBindingResult:
    if decision_time < binding.effective_from:
        return PolicyBindingResult(TriState.FAIL, "POLICY_NOT_YET_EFFECTIVE")

    if binding.effective_until is not None and decision_time >= binding.effective_until:
        return PolicyBindingResult(TriState.FAIL, "POLICY_EXPIRED_AT_DECISION_TIME")

    if not binding.policy_hash:
        return PolicyBindingResult(TriState.UNKNOWN, "POLICY_HASH_UNKNOWN")

    return PolicyBindingResult(TriState.PASS, "POLICY_VALID_AT_DECISION_TIME")
