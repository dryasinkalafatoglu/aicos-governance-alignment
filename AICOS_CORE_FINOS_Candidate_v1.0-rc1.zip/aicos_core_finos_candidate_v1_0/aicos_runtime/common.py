from dataclasses import dataclass
from enum import Enum
from typing import Optional

class TriState(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    UNKNOWN = "UNKNOWN"

class Permission(str, Enum):
    ALLOW = "ALLOW"
    DOWNGRADE = "DOWNGRADE"
    HOLD = "HOLD"
    BLOCK = "BLOCK"

class IndependenceStatus(str, Enum):
    INDEPENDENT = "INDEPENDENT"
    NOT_INDEPENDENT = "NOT_INDEPENDENT"
    UNKNOWN = "UNKNOWN"
