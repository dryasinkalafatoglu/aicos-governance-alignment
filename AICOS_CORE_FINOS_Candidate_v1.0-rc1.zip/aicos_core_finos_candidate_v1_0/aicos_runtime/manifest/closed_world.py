from dataclasses import dataclass
from pathlib import PurePosixPath
from typing import Iterable, Set, Tuple
from aicos_runtime.common import TriState

@dataclass(frozen=True)
class ManifestResult:
    status: TriState
    reason: str
    unexpected: Tuple[str, ...] = ()
    missing: Tuple[str, ...] = ()

def evaluate_closed_world_manifest(
    expected_paths: Iterable[str],
    observed_paths: Iterable[str],
    allowed_roots=("aicos_runtime", "policies", "trust"),
) -> ManifestResult:
    expected: Set[str] = {str(PurePosixPath(p)) for p in expected_paths}
    observed: Set[str] = {str(PurePosixPath(p)) for p in observed_paths}

    for p in observed:
        root = PurePosixPath(p).parts[0] if PurePosixPath(p).parts else ""
        if root not in allowed_roots:
            return ManifestResult(TriState.FAIL, "PATH_OUTSIDE_CLOSED_WORLD", (p,), ())

    unexpected = tuple(sorted(observed - expected))
    missing = tuple(sorted(expected - observed))

    if unexpected:
        return ManifestResult(TriState.FAIL, "UNEXPECTED_ARTIFACT_PRESENT", unexpected, missing)
    if missing:
        return ManifestResult(TriState.FAIL, "EXPECTED_ARTIFACT_MISSING", unexpected, missing)

    return ManifestResult(TriState.PASS, "CLOSED_WORLD_MANIFEST_MATCH")
