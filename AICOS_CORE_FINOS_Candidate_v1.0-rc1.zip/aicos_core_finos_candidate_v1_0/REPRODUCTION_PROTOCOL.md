# Reproduction Protocol

## Objective

Reproduce the local AICOS CORE control-suite result and challenge its fail-closed invariants.

## Commands

```bash
python -m pip install --upgrade pytest
python -m pytest -q
```

Repeat the test run three times in the same clean environment, then repeat in a second clean environment if available.

## Record

- archive or commit SHA-256
- OS
- Python version
- pytest version
- run count
- pass/fail totals
- any non-deterministic result
- any modified fixture
- any unintended PASS

## Result labels

Use only:

- `REPRODUCED`
- `FAILED`
- `NOT_REPRODUCIBLE`

Do not translate `REPRODUCED` into `INDEPENDENTLY_VALIDATED` unless the independence requirements in `FINOS_REVIEW_PACKET.md` are separately established.
