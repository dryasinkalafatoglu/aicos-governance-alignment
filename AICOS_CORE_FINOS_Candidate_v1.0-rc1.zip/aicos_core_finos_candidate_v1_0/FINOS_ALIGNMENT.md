# FINOS Alignment Note — AICOS CORE

## Boundary

This document is an engineering mapping, not a statement of FINOS endorsement, certification, adoption, or formal conformance.

The comparison uses current public materials in the FINOS `ai-governance-framework` repository observed on 24 September 2026.

## Why the AICOS steel thread is finance-specific

FINOS `uc-1 Credit Risk Analysis` describes an agent that processes small-business loan applications, including financial documents, internal policy checks, risk scoring, written justification, source references, audit trail, and data-quality concerns.

AICOS does not replace that agent. It acts at the reliance boundary after an AI/agent has produced an output and before a consequential institutional action is permitted.

```text
Credit / AI Agent
        |
  recommendation
        |
        v
AICOS Decision Assurance
 evidence | time | authority | health | policy | provenance
        |
 PASS / HOLD / BLOCK / ABSTAIN
        |
        v
Institutional human / controlled execution path
```

## Direct technical mapping

| FINOS artifact | Relevant concern | AICOS control surface | AICOS evidence boundary |
|---|---|---|---|
| `uc-1` Credit Risk Analysis | source-grounded credit analysis, audit trail, current data | evidence provenance, freshness, policy binding, decision record | does not claim credit-model correctness |
| `ri-24` Agent Action Authorization Bypass | agent exceeds approval / tool / workflow authority | action-authority gate, tool/authority binding, BLOCK on invalid grant | does not replace enterprise IAM |
| `ri-6` Non-Deterministic Behaviour | repeatability and testing difficulty | deterministic decision/replay contract over bound state | replayability is not evidence |
| `ri-19` Data Quality and Drift | stale/poor data and changing conditions | decision-time freshness and health binding | does not prove source truth beyond supplied evidence |
| `mi-10` AI Model Version Pinning | version drift | version/hash binding in replay and release envelope | version pinning alone does not prove safety |
| `mi-4` AI System Observability | operational monitoring | health/observability dimension and UNKNOWN fail-closed behavior | observability signal does not override hard failure |
| `mi-5` System Acceptance Testing | acceptance criteria, representative failure cases, evidence | adversarial/regression corpus and explicit failure conditions | local tests are not production acceptance |
| `mi-11` Human Feedback Loop | human oversight and issue feedback | human/institutional authority boundary; adverse findings can revoke claims | human approval is not a substitute for missing evidence |

## FINOS-specific contribution hypothesis

The narrow contribution hypothesis is not "another governance framework."

It is an executable example of **decision-time reliance enforcement** for a finance use case where:

1. an AI/agent produces a recommendation;
2. evidence and policy state are bound to decision time;
3. authority is validated independently of model output;
4. missing/unknown mandatory state cannot silently become PASS;
5. revocation can invalidate dependent evidence and claims;
6. replay reconstructs the bound state without being misrepresented as independent evidence;
7. external review can reproduce a scoped result without implying production safety.

## Open questions for FINOS reviewers

- Is decision-time reliance permission a useful control surface to express explicitly in the finance AI governance stack?
- Which existing FINOS mitigation/risk artifacts should own or reference this control surface?
- Should evidence admissibility and authority remain separate control concepts?
- What minimum machine-readable receipt would be useful for cross-implementation evaluation?
- Which adversarial cases would FINOS reviewers add to falsify this steel thread?

## Non-claims

This mapping does not say:
- FINOS has approved AICOS;
- AICOS is FINOS-compliant;
- any FINOS artifact requires AICOS;
- this package is independently validated;
- this package is production-ready.
