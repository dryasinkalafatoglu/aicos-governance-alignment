from dataclasses import dataclass
from typing import Dict

@dataclass(frozen=True)
class BenchmarkDecision:
    result: str
    reason: str

def evaluate_case(case: Dict) -> BenchmarkDecision:
    checks = [
        ("evidence_fresh", "STALE_EVIDENCE"),
        ("mandatory_evidence_present", "MANDATORY_EVIDENCE_MISSING"),
        ("authority_valid", "AUTHORITY_INVALID"),
        ("dependency_healthy", "DEPENDENCY_FAILURE"),
        ("policy_hash_match", "POLICY_HASH_DRIFT"),
        ("trust_root_match", "TRUST_ROOT_DRIFT"),
        ("tool_binding_match", "TOOL_BINDING_MISMATCH"),
        ("receipt_integrity", "RECEIPT_INTEGRITY_FAILURE"),
    ]

    if case.get("authority_revoked") is True:
        return BenchmarkDecision("BLOCK", "AUTHORITY_REVOKED")

    for field, reason in checks:
        value = case.get(field)
        if value is None:
            return BenchmarkDecision("ABSTAIN", f"{reason}_UNKNOWN")
        if value is False:
            return BenchmarkDecision("BLOCK", reason)

    return BenchmarkDecision("PASS", "ALL_MANDATORY_ASSURANCE_CHECKS_PASS")
