from dataclasses import dataclass
from typing import Any, Dict, Tuple

@dataclass(frozen=True)
class AltDecision:
    result: str
    reason: str

# Declarative rule table; intentionally separate implementation shape from benchmark/evaluator.py.
# This is NOT an independent verifier because it was authored in the same project and against
# the same published corpus.
RULES: Tuple[Tuple[str, str, Any, str], ...] = (
    ("authority_revoked", "is", True, "AUTHORITY_REVOKED"),
    ("evidence_fresh", "is", False, "STALE_EVIDENCE"),
    ("mandatory_evidence_present", "is", False, "MANDATORY_EVIDENCE_MISSING"),
    ("authority_valid", "is", False, "AUTHORITY_INVALID"),
    ("dependency_healthy", "is", False, "DEPENDENCY_FAILURE"),
    ("policy_hash_match", "is", False, "POLICY_HASH_DRIFT"),
    ("trust_root_match", "is", False, "TRUST_ROOT_DRIFT"),
    ("tool_binding_match", "is", False, "TOOL_BINDING_MISMATCH"),
    ("receipt_integrity", "is", False, "RECEIPT_INTEGRITY_FAILURE"),
)

UNKNOWN_FIELDS = (
    "evidence_fresh",
    "mandatory_evidence_present",
    "authority_valid",
    "dependency_healthy",
    "policy_hash_match",
    "trust_root_match",
    "tool_binding_match",
    "receipt_integrity",
)

def evaluate_case_alt(case: Dict[str, Any]) -> AltDecision:
    for field in UNKNOWN_FIELDS:
        if case.get(field) is None:
            return AltDecision("ABSTAIN", f"{field.upper()}_UNKNOWN")

    for field, op, value, reason in RULES:
        if op == "is" and case.get(field) is value:
            return AltDecision("BLOCK", reason)

    return AltDecision("PASS", "ALL_MANDATORY_ASSURANCE_CHECKS_PASS")
