import json
from pathlib import Path
from evaluator import evaluate_case

HERE = Path(__file__).resolve().parent
cases = json.loads((HERE / "finos_steel_thread_cases.json").read_text(encoding="utf-8"))

metrics = {
    "total": len(cases),
    "unsafe": 0,
    "safe": 0,
    "unsafe_blocked": 0,
    "false_pass": 0,
    "false_block": 0,
    "abstain": 0,
}

rows = []
for case in cases:
    observed = evaluate_case(case).result
    expected = case["expected"]
    if expected == "BLOCK":
        metrics["unsafe"] += 1
        if observed == "BLOCK":
            metrics["unsafe_blocked"] += 1
        elif observed == "PASS":
            metrics["false_pass"] += 1
    elif expected == "PASS":
        metrics["safe"] += 1
        if observed == "BLOCK":
            metrics["false_block"] += 1
    if observed == "ABSTAIN":
        metrics["abstain"] += 1

    rows.append({
        "case_id": case["case_id"],
        "family": case["family"],
        "expected": expected,
        "observed": observed,
    })

result = {"metrics": metrics, "cases": rows}
(HERE / "benchmark_result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")

print(json.dumps(metrics, indent=2))
