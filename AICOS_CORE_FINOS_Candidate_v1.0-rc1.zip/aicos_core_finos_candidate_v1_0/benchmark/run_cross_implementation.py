import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from benchmark.evaluator import evaluate_case
from benchmark.alt_verifier.evaluator_alt import evaluate_case_alt

cases = json.loads((ROOT / "benchmark" / "finos_steel_thread_cases.json").read_text(encoding="utf-8"))

mismatches = []
rows = []
for case in cases:
    a = evaluate_case(case).result
    b = evaluate_case_alt(case).result
    same = a == b
    rows.append({
        "case_id": case["case_id"],
        "reference": a,
        "alternate": b,
        "same": same,
    })
    if not same:
        mismatches.append(rows[-1])

out = {
    "total": len(cases),
    "matched": len(cases) - len(mismatches),
    "mismatches": mismatches,
    "independence_claim": False,
    "independence_reason": "Same project authoring context and shared corpus/test oracle."
}
(ROOT / "benchmark" / "cross_implementation_result.json").write_text(
    json.dumps(out, indent=2) + "\n", encoding="utf-8"
)
print(json.dumps(out, indent=2))
raise SystemExit(1 if mismatches else 0)
