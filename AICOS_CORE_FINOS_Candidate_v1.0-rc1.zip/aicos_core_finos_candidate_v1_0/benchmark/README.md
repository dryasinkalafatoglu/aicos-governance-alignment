# FINOS-Facing Decision Assurance Steel Thread Benchmark v1.0

This benchmark contains **100 deterministic synthetic scenarios** across ten families:

1. stale evidence
2. missing mandatory evidence
3. invalid authority
4. revoked authority
5. dependency failure
6. policy-hash drift
7. trust-root drift
8. tool substitution
9. tampered receipt
10. clean control

Each family contains 10 cases.

Expected distribution:

- 100 total
- 90 deliberately unsafe
- 10 clean controls
- 90 unsafe cases expected to BLOCK
- 10 clean controls expected to PASS

This corpus is intentionally simple and inspectable. Its purpose is falsification of fail-closed decision-assurance behavior, not demonstration of model intelligence or production safety.

Run:

```bash
cd benchmark
python run_benchmark.py
```

or:

```bash
python -m pytest -q
```

A successful local run is first-party evidence only.
