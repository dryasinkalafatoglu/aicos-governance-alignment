# External Reproduction Attestation Template

## Reviewer identity
- Name:
- Organization:
- Date:
- Relationship to AICOS:
- Prior exposure to expected results: YES / NO / UNKNOWN
- Prior exposure to implementation internals: YES / NO / UNKNOWN
- Corpus-driven correction before final rerun: YES / NO

## Environment
- OS:
- Architecture:
- Python:
- pytest:
- Container runtime:
- Commit SHA or archive SHA-256:

## Execution
```text
python -m pytest -q
cd benchmark && python run_benchmark.py
python review/run_mutations.py
```

## Independence dimensions
- Different operator: PASS / FAIL / UNKNOWN
- Different execution environment: PASS / FAIL / UNKNOWN
- Different implementation: PASS / FAIL / NOT_APPLICABLE / UNKNOWN
- Shared source code: YES / NO / UNKNOWN
- Shared test oracle: YES / NO / UNKNOWN
- Expected outputs disclosed: YES / NO / UNKNOWN
- Corpus influenced implementation correction: YES / NO

## Deviations
List every deviation, unexpected PASS, non-deterministic result, environment issue or undocumented dependency.

## Reviewer conclusion
Choose one:
- REPRODUCED
- FAILED
- NOT_REPRODUCIBLE

Do not label the result "independently validated" unless the relevant independence dimensions are separately established and documented.
