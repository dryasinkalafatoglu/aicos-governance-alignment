# Cross-Implementation Review Guide

This package now includes two verifier implementations:

- `benchmark/evaluator.py`
- `benchmark/alt_verifier/evaluator_alt.py`

They are intentionally written using different implementation structures and are compared across the full 100-case corpus.

Important boundary:

> Agreement between these two implementations is **not independent confirmation**.

Both implementations were produced within the same project context and use the same corpus and expected outcomes. Their value is narrower: they can expose accidental implementation-specific behavior and provide a baseline for a truly external verifier.

Run:

```bash
cd benchmark
python run_cross_implementation.py
```

A third party seeking to establish stronger independence should implement the control contract without reusing either verifier's source code, then document whether expected outputs or corpus fixes were disclosed before final execution.
