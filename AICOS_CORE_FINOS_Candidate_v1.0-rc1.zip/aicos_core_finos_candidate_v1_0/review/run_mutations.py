from copy import deepcopy
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from benchmark.evaluator import evaluate_case

BASE = {
    "case_id": "MUT-BASE", "family": "clean_control", "expected": "PASS",
    "evidence_fresh": True, "mandatory_evidence_present": True,
    "authority_valid": True, "authority_revoked": False,
    "dependency_healthy": True, "policy_hash_match": True,
    "trust_root_match": True, "tool_binding_match": True,
    "receipt_integrity": True,
}
MUTATIONS = {
    "stale_evidence": ("evidence_fresh", False, "BLOCK"),
    "missing_evidence": ("mandatory_evidence_present", False, "BLOCK"),
    "invalid_authority": ("authority_valid", False, "BLOCK"),
    "revoked_authority": ("authority_revoked", True, "BLOCK"),
    "dependency_failure": ("dependency_healthy", False, "BLOCK"),
    "policy_drift": ("policy_hash_match", False, "BLOCK"),
    "trust_root_drift": ("trust_root_match", False, "BLOCK"),
    "tool_substitution": ("tool_binding_match", False, "BLOCK"),
    "receipt_tamper": ("receipt_integrity", False, "BLOCK"),
}
results, failed = [], False
for name, (field, value, expected) in MUTATIONS.items():
    case = deepcopy(BASE)
    case["case_id"] = f"MUT-{name}"
    case[field] = value
    observed = evaluate_case(case).result
    ok = observed == expected
    results.append({"mutation":name,"expected":expected,"observed":observed,"ok":ok})
    failed |= not ok

case = deepcopy(BASE)
case["case_id"] = "MUT-unknown-evidence"
case["evidence_fresh"] = None
observed = evaluate_case(case).result
ok = observed == "ABSTAIN"
results.append({"mutation":"unknown_evidence","expected":"ABSTAIN","observed":observed,"ok":ok})
failed |= not ok

out = {"results":results,"passed":sum(r["ok"] for r in results),"total":len(results)}
(ROOT/"review"/"mutation_results.json").write_text(json.dumps(out, indent=2)+"\n", encoding="utf-8")
print(json.dumps(out, indent=2))
raise SystemExit(1 if failed else 0)
