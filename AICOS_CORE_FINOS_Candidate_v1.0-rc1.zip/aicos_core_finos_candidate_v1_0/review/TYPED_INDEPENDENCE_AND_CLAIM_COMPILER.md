# Typed Independence & Evidence-Bound Claim Compiler

AICOS CORE no longer treats verifier independence as one coarse boolean.

The candidate model separates:

- implementation diversity
- evaluation independence
- organizational independence
- execution independence
- oracle independence
- trust-path independence

Each dimension is `PASS / FAIL / UNKNOWN`.

This matters because a verifier corrected after seeing the evaluated corpus can still be a different implementation while **failing evaluation independence for that corpus**.

The claim compiler therefore binds each claim type to explicit prerequisites. A claim can only be authorized if every required dimension passes.

Examples:

- `cross_implementation_reproduced_after_correction` may remain valid when implementation diversity is PASS and evaluation independence is FAIL, provided the phrase explicitly preserves the correction boundary.
- `independently_validated` requires stronger independence dimensions and is blocked if corpus-driven correction contaminated the evaluation.
- `production_proven` cannot be inferred from independent validation; it separately requires production evidence.

Invariant:

`SignedEvidence != IndependentEvidence`

and:

`ClaimStrength <= EvidenceStrength`
